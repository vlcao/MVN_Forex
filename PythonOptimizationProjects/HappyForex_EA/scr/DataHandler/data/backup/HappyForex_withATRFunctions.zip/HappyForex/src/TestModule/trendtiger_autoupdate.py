'''
//+------------------------------------------------------------------+
//|Artificial_Neuron_Vol.3.0.4_kairyou_4S.mq4                        |
//|Barca2.1Ver-15_20160328_GBPUSD_20160419_1                         |
//|TradeFighter_EURUSD                                               |
//|オーダーシステム                                                  |
//|http://fx.klhappiness.org/index.html                              |
//+------------------------------------------------------------------+
//プロパティ、設定
#property copyright "Copyright 2016.11.11 Knowledge Library for Happiness Limited Company."
#property link      "http://fx.klhappiness.org/index.html"
#property link      "http://klhappiness.org/index.html"
#property version   "1.00"

#include <stdlib.mqh>
#include <SocketLib.mqh>

#define      STR_OBJ_PREFIX    "MVN_TRENDTIGER__"

enum HistoryDataOption
{
    year_1 = 1,
    year_2 = 2,
    year_3 = 3,
    year_4 = 4,
    year_5 = 5,
    year_6 = 6,
    year_7 = 7,
    year_8 = 8,
    year_9 = 9,
    year_10 = 10
};

////////////////////////////////////
////////////////////////////////////
//lots
extern   double   LOT_SIZE        = 0.01; //LOT SIZE
input    int      MAGIC_NUMBER = 22;
input    HistoryDataOption      HISTORY_DATA_LENGTH = year_1;//HISTORY DATA LENGTH(days)
input    int      OPTIMIZE_INTEVAL = 30;//OPTIMIZE INTEVAL(days)
input    int      PARAMETER_TIME_LIFE = 30;//PARAMETER TIME LIFE(days)
input    int      WAIT_BEFORE_RETRY = 15;//WAIT BEFORE_RETRY(minutes)
////////////////////////////////////
input    string   EA_SERVER = "14.177.235.177";//EA SERVER
//input string   EA_SERVER = "172.16.4.200";//EA SERVER
input    int      EA_PORT   = 5589;//EA PORT
extern   string  SYMBOL_CODE = "";

string EA_CODE = "TrendTiger.2017.1.00";
string EA_NAME = "TrendTiger    ";
string DATA_SEP = "|";
SOCKET client  = INVALID_SOCKET; // client socket
bool TRADE_DISABLE = TRUE;
string RESULT_CODE_AUTH_FAILED = "NOT_AUTH";
string RESULT_CODE_AUTH_OK = "AUTH_OK";
string RESULT_NOT_FOUND_MSG = "RESULT_NOT_FOUND";

int      itemCount_time1 = 16;
int      itemCount_time2 = 13;
int      itemCount_time3 = 16;
int      itemCount_time4 = 49;
int      itemCount_time6 = 49;
int      itemCount_time7 = 10;
int      itemCount_time8 = 40;

////////////////////////////////////
int      AOI1        = 19;
int      AOI2        = 1;
int      AOI3        = 10;
int      AOI4        = 49;
int      AOI6        = 1;
int      AOI7        = 4;
int      AOI8        = 16;
////////////////////////////////////
int      time1       = PERIOD_M15;//Force OPEN
int      time2       = PERIOD_M15;//Force OPEN
int      time3       = PERIOD_M30;//Force OPEN
int      time4       = PERIOD_M30;//Force OPEN
int      time6       = PERIOD_M15;//Force OPEN
int      time7       = PERIOD_M15;//Force OPEN
int      time8       = PERIOD_M5;//Force OPEN
int      time5       = PERIOD_M15;//ＡＤＸ（Average Directional Movement Index）【iADX】
int      ADX_period_time5=14;

////////////////////////////////////////////////////////////
int      time25            = PERIOD_M30;//MA OPEN
int      AAA               = 12;
int      ma_period_time25  = 49;
double   Const_Buy_time25  = 0.2700;
double   Const_Sell_time25 = 0.0000;
double   Const_Buy_time25_MAX  = 9.00000;
double   Const_Sell_time25_MAX = 9.00000;


int      time26            = PERIOD_M30;//MA OPEN
int      BBB               = 2;
int      ma_period_time26  = 49;
double   Const_Buy_time26  = 0.0100;
double   Const_Sell_time26 = 1.0100;
double   Const_Buy_time26_MAX  = 9.00000;
double   Const_Sell_time26_MAX = 9.00000;


int      time27            = PERIOD_H1;//MA OPEN
int      CCC               = 5;
int      ma_period_time27  = 49;
double   Const_Buy_time27  = 2.5600;
double   Const_Sell_time27 = 0.9000;
double   Const_Buy_time27_MAX  = 9.00000;
double   Const_Sell_time27_MAX = 9.00000;


int      time28            = PERIOD_H1;//MA OPEN
int      DDD               = 10;
int      ma_period_time28  = 16;
double   Const_Buy_time28  = 0.4800;
double   Const_Sell_time28 = 0.3100;
double   Const_Buy_time28_MAX  = 9.00000;
double   Const_Sell_time28_MAX = 9.00000;

int      time31            = PERIOD_H1;//MA OPEN
int      FFF               = 2;
int      ma_period_time31  = 49;
double   Const_Buy_time31  = 0.0000;
double   Const_Sell_time31 = 1.0400;
double   Const_Buy_time31_MAX  = 9.00000;
double   Const_Sell_time31_MAX = 9.00000;


int      time32            = PERIOD_H1;//MA OPEN
int      GGG               = 2;
int      ma_period_time32  = 19;
double   Const_Buy_time32  = 3.8400;
double   Const_Sell_time32 = 2.1900;
double   Const_Buy_time32_MAX  = 9.00000;
double   Const_Sell_time32_MAX = 9.00000;


int      time33            = PERIOD_H1;//MA OPEN
int      HHH               = 1;
int      ma_period_time33  = 43;
double   Const_Buy_time33  = 3.0425;
double   Const_Sell_time33 = 2.5650;
double   Const_Buy_time33_MAX  = 9.00000;
double   Const_Sell_time33_MAX = 9.00000;


int      time34            = PERIOD_H1;//MA OPEN
int      III               = 4;
int      ma_period_time34  = 48;
double   Const_Buy_time34  = 1.6960;
double   Const_Sell_time34 = 0.9256;
double   Const_Buy_time34_MAX  = 9.00000;
double   Const_Sell_time34_MAX = 9.00000;
////////////////////////////////////////////////////////////

int      time29                = PERIOD_M5;//ウィリアムズ %R（Williams Percent Range）【iWPR】 OPEN
int      wpr_period_time29     = 1;
double   wpr_conts_buy_time29  = -70.00;
double   wpr_conts_sell_time29 = -30.00;

int      time30                = PERIOD_M5;//ウィリアムズ %R（Williams Percent Range）【iWPR】 OPEN
int      wpr_period_time30     = 1;
double   wpr_conts_buy_time30  = -70.00;
double   wpr_conts_sell_time30 = -30.00;

////////////////////////////////////////////////////////////


int      force_period_time1    = 40;//Force
int      force_period_time2    = 19;//Force
int      force_period_time3    = 25;//Force
int      force_period_time4    = 1;//Force
int      force_period_time6    = 31;//Force
int      force_period_time7    = 43;//Force
int      force_period_time8    = 10;//Force

double   Const_sell_time1      = 0.38000;//perceptron1() >=Const_time1 BUY OR SELL Judge
double   Const_sell_time2      = 0.16000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_sell_time3      = 0.00000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_sell_time4      = 4.50000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_sell_time6      = 1.55000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_sell_time7      = 0.79000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_sell_time8      = 2.10000;//perceptron2() >=Const_time1 BUY OR SELL Judge

double   Const_buy_time1       = 0.08000;//perceptron1() >=Const_time1 BUY OR SELL Judge
double   Const_buy_time2       = 0.00000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_buy_time3       = 0.11000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_buy_time4       = 0.69000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_buy_time6       = 3.31000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_buy_time7       = 1.46000;//perceptron2() >=Const_time1 BUY OR SELL Judge
double   Const_buy_time8       = 0.03000;//perceptron2() >=Const_time1 BUY OR SELL Judge
////////////////////////////////////
int     spread    = 3;
double  XXX       = 1.00;//lots * XXX
double  YYY       = 1.00;//sl * YYY  + spread
// StopLoss level
double  sl_sell1  = 38;
double  sl_sell2  = 24;
double  sl_sell3  = 159;
double  sl_sell4  = 93;
double  sl_sell5  = 159;
double  sl_sell6  = 58;
double  sl_sell7  = 179;
double  sl_sell8  = 168;
double  sl_sell9  = 183;
double  sl_sell10 = 136;
double  sl_sell11 = 199;
double  sl_sell12 = 82;
double  sl_sell13 = 78;


double sl_buy1  = 1;
double sl_buy2  = 20;
double sl_buy3  = 187;
double sl_buy4  = 126;
double sl_buy5  = 65;
double sl_buy6  = 186;
double sl_buy7  = 131;
double sl_buy8  = 180;
double sl_buy9  = 78;
double sl_buy10 = 92;
double sl_buy11 = 27;
double sl_buy12 = 36;
double sl_buy13 = 129;

double tp_buy1  = 129;
double tp_buy2  = 112;
double tp_buy3  = 130;
double tp_buy4  = 75;
double tp_buy5  = 136;
double tp_buy6  = 10;
double tp_buy7  = 32;
double tp_buy8  = 164;
double tp_buy9  = 163;
double tp_buy10 = 196;
double tp_buy11 = 179;

double tp_sell1  = 197;
double tp_sell2  = 16;
double tp_sell3  = 193;
double tp_sell4  = 166;
double tp_sell5  = 136;
double tp_sell6  = 158;
double tp_sell7  = 24;
double tp_sell8  = 181;
double tp_sell9  = 97;
double tp_sell10 = 44;
double tp_sell11 = 130;

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
int  time11 = PERIOD_M5;//High,Low
int    waite_BUY1=1000;//Close Time
int    waite_SELL1=1000;//Close Time

int    waite_BUY3=1000;//Close Time
int    waite_SELL3=1000;//Close Time

int    waite_BUY4=1000;//Close Time
int    waite_SELL4=1000;//Close Time


int      waite_BUY5         = 1000;//Close Time
int      waite_SELL5        = 1000;//Close Time

int      waite_BUY6         = 15;
int      waite_SELL6        = 15;

int    time12             = PERIOD_H1;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time12 = 100;
double siguma_time12      = 10.0;

int    time13             = PERIOD_H1;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time13 = 100;
double siguma_time13      = 10.0;

int    time14             = PERIOD_H1;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time14 = 100;
double siguma_time14      = 10.0;

int    time15             = PERIOD_H1;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time15 = 100;
double siguma_time15      = 10.0;

int    time16             = PERIOD_M30;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time16 = 100;
double siguma_time16      = 10.0;

int    time17             = PERIOD_M30;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time17 = 100;
double siguma_time17      = 10.0;

int    time20             = PERIOD_M15;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time20 = 100;
double siguma_time20      = 10.0;

int    time21             = PERIOD_M15;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time21 = 100;
double siguma_time21      = 10.0;

int    time22             = PERIOD_M5;//ボリンジャーバンド（Bollinger bands）【iBands】
int    band_period_time22 = 100;
double siguma_time22      = 10.0;


int    time18             = PERIOD_M5;//High,Low
int    time19             = PERIOD_M15;//High,Low
/////////////////////////////////////////////////////////////////////////////////////////////////////////

//int time5 = PERIOD_M15;//ＡＤＸ（Average Directional Movement Index）【iADX】
//int ADX_period_time5=7;
double ADX_time5_Const1  = 10.000;
double ADX_time5_Const2  = 20.000;
double ADX_time5_Const3  = 30.000;
double ADX_time5_Const4  = 40.000;
double ADX_time5_Const5  = 50.000;
double ADX_time5_Const6  = 60.000;
double ADX_time5_Const7  = 70.000;
double ADX_time5_Const8  = 80.000;
double ADX_time5_Const9  = 90.000;
double ADX_time5_Const10 = 100.000;

int    BuyEntryMaxNumber  = 10;
int    SellEntryMaxNumber = 10;

int    TakeProfitDefaultBuy  = 50;
int    TakeProfitDefaultSell = 50;
int    StopLossDefaultBuy    = 50;
int    StopLossDefaultSell   = 50;

bool ECN_Mode = false;
//static int prevtime = 0;
double pipValue=0.00;
double  Golden_Ratio = 1.618033988749894848204586834365638117720309179805762862135448622705260462818902449707207204189391137484754088075386891752;
double  root2=1.41421356237309504880168872420969807856967187537694807317667973799073247846210703885038753432764157;

int gCountBuy = 0;
int gCountSell = 0;

int minTimeFrame = 0;
datetime lastTimeCheckPoint = 0;
datetime lastBuyTime = 0;
datetime lastSellTime = 0;
datetime lastOpenTime = 0;

/*
the time when optimized parameter set is generated
*/
datetime ParameterTimeBroker = 0;
datetime LastRetryTime = 0;

bool updatedFlag = False;
bool isOutOfDate = False;
string errorMessage = "";

bool getStringParameter(string parameterName, string &value) {
   int res = writeString(parameterName);
   if (res <= 0) return False;
   string parameterVal = "";
   res = readString(value);
   if (res <= 0) return False;
   PrintFormat("%s=%s", parameterName, value);
   return True;
}


void displayMessage(string strMessage, color color4Message) {
    string strMessageID = StringConcatenate(STR_OBJ_PREFIX, "_h2Tite1");
    ObjectDelete(strMessageID);          
    //TextLabel(strTxtIndicatorName, 12, 22, CORNER_LEFT_UPPER, INDICATOR_LABEL, 11, "Arial Bold", Yellow);   
    //PrintFormat("Displaying messages[%s]", strMessage);
    TextLabel(strMessageID, 12, 12, CORNER_LEFT_UPPER, strMessage , 10, "Arial Bold", color4Message);   
}

void displayMessage2(string strMessage, color color4Message) {
    string strMessageID = StringConcatenate(STR_OBJ_PREFIX, "_h2Tite2");
    ObjectDelete(strMessageID);          
    //TextLabel(strTxtIndicatorName, 12, 22, CORNER_LEFT_UPPER, INDICATOR_LABEL, 11, "Arial Bold", Yellow);   
    //PrintFormat("Displaying messages[%s]", strMessage);
    TextLabel(strMessageID, 12, 30, CORNER_LEFT_UPPER, strMessage , 10, "Arial Bold", color4Message);   
}

void clearAllObject() {
  //PrintFormat("----clear all objects");
  //ObjectsDeleteAll(0, STR_OBJ_PREFIX, 0, OBJ_ARROW); 
  //ObjectsDeleteAll(0, STR_OBJ_PREFIX, 0, OBJ_HLINE);         
  //ObjectsDeleteAll(0, STR_OBJ_PREFIX, 0, OBJ_TREND);  
  ObjectsDeleteAll(0, STR_OBJ_PREFIX, 0, OBJ_LABEL);    
}

//#<symbol><DATA_SEP><timeframe><DATA_SEP><frequence><DATA_SEP><history_length>
//#<ea code>.<loginID>.<broker>.<symbol>.<timeframe>.<frequence>.<history_length>
bool updateParameter(){
    isOutOfDate = False;
    if (IsTesting()) return True;
    updatedFlag = False;
    displayMessage("Connecting to server " + EA_SERVER + ":" + IntegerToString(EA_PORT) + " ...", clrWhite);  
    LastRetryTime = TimeCurrent();
    string strComment;
    //SOCKET client=INVALID_SOCKET; // client socket
    if (!StartClient(EA_SERVER, EA_PORT)) {
      strComment = StringConcatenate("Could not connect to ", EA_SERVER, ":", IntegerToString(EA_PORT));
      //Comment(strComment);
      displayMessage(strComment, clrRed);  
      errorMessage = "[" + strComment + "]";
      return False;
    }
    
    string requestSymbol = Symbol();
    
    if (StringLen(SYMBOL_CODE) > 0) {
      requestSymbol = SYMBOL_CODE;
    } else {
       if (StringLen(Symbol()) > 6) {
         requestSymbol = StringSubstr(Symbol(), 0, 6);
       };
    }
    
    string request = StringConcatenate(EA_CODE, DATA_SEP, AccountCompany()
         , DATA_SEP, IntegerToString(AccountNumber()), DATA_SEP, requestSymbol, DATA_SEP, IntegerToString(Period())
         , DATA_SEP, IntegerToString(OPTIMIZE_INTEVAL), DATA_SEP, IntegerToString(365*HISTORY_DATA_LENGTH), DATA_SEP, IntegerToString(IsDemo()), DATA_SEP, IntegerToString(IsTesting()));
         
    //PrintFormat("request[%s]", request);   
    //uchar data[];      
    //StringToCharArray(request, data);   
    //int len = ArraySize(data);
    //int res = send(client, data, len, 0);//send request
    
    //Send request
    int res = writeString(request);
    if(res == SOCKET_ERROR) {
      strComment = "Send request failure";
      displayMessage(strComment, clrRed);  
      //Comment(strComment);
      errorMessage = "[" + strComment + "]";
      Close(client);
      client=INVALID_SOCKET;
      return False;
    } else {
      strComment = "Sent request[" + request + "]";
      errorMessage = "[" + strComment + "]";
      displayMessage(strComment, clrBlue);
      //Comment(strComment);
    }
    
    string strReceive;    
    int resLengh = readString(strReceive);
    /*
    int retryCount = 0;
    while ((resLengh == 0) && (retryCount < 10)) {
      Sleep(1000);
      retryCount = retryCount + 1;
      resLengh = readString(strReceive);
      PrintFormat("Read data from server, retry = %d, result = %d", retryCount, resLengh);
    };
    */
    
    if (resLengh <= 0) {
      //Comment("Error: could not read data from server");
      strComment = StringConcatenate(EA_NAME, "Error: could not read data from server");
      //Comment(StringConcatenate(EA_NAME, "Error: could not read data from server"));
      //Comment(strComment);
      displayMessage(strComment, clrRed);
      Print(strComment);
      errorMessage = "[" + strComment + "]";
      Close(client);
      return False;
    } else {
      printf ("response = '%s'[%d]", strReceive, resLengh);
      if (strReceive == RESULT_CODE_AUTH_FAILED) {
         strComment = StringConcatenate(EA_NAME, "Authentication failed");
         //Comment(strComment);
         displayMessage(strComment, clrRed);
         errorMessage = "[" + strComment + "]";         
         Print(strComment);
         Close(client);
         return False;
      } else if (strReceive == RESULT_CODE_AUTH_OK){
         strComment = StringConcatenate(EA_NAME, "Authentication OK");
         //Comment(strComment);
         displayMessage(strComment, clrBlue);
         Print(strComment);
         errorMessage = "[" + strComment + "]";
      } else if (strReceive == RESULT_NOT_FOUND_MSG) {
         strComment = StringConcatenate(EA_NAME, "Optimization data does not exist");
         //Comment(strComment);
         displayMessage(strComment, clrRed);
         errorMessage = "[" + strComment + "]";
         Print(strComment);      
         Close(client);
         return False;                  
      } else {
         strComment = StringConcatenate(EA_NAME, "Unknown response");
         //Comment(strComment);
         displayMessage(strComment, clrRed);
         errorMessage = "[" + strComment + "]";
         Print(strComment);      
         Close(client);
         return False;                        
      };
      
    };
    
    //Authentication successfull    
    //Start updating values for parameters
    Print("Start getting parameter");
    displayMessage("Start getting parameter", clrBlue);
    string parameterName = "";
    //string createTime = 
    
    /*
    Validate create time
    CREATE_TIME=2017.03.08 17:05:57
    */
    string strCreateTime = "";
    datetime parameterTime;
    int parameterServerTimeZone = 0;
    parameterName = "CREATE_TIME";
    if (!getStringParameter(parameterName, strCreateTime)) {
        getParameterFail(parameterName);
        return False;
    }
    string dateTimeItems[];
    string dateItems[];
    string timeItems[];
    
    int itemsCount = StringSplit(strCreateTime, ' ',dateTimeItems);    
    if (itemsCount != 2) {
      Print("Invalid time format");
      displayMessage("Invalid time format", clrRed);
      errorMessage = "[Invalid time format]";
      return False;
    }
    
    itemsCount = StringSplit(dateTimeItems[0], '.', dateItems);    
    if (itemsCount != 3) {
      Print("Invalid time format");
      errorMessage = "[Invalid time format]";
      displayMessage("Invalid time format", clrRed);
      return False;
    }

    itemsCount = StringSplit(dateTimeItems[1], ':', timeItems);    
    if (itemsCount != 3) {
      Print("Invalid time format");
      errorMessage = "[Invalid time format]";
      displayMessage("Invalid time format", clrRed);
      return False;
    }        
    
    parameterTime = StrToTime(strCreateTime);
   
    parameterName = "TIME_ZONE";
    if (!getIntParameter(parameterName, parameterServerTimeZone)) {
        getParameterFail(parameterName);
        return False;
    }    
    
    datetime parameterTimeGMT = parameterTime - parameterServerTimeZone*3600;
    ParameterTimeBroker = parameterTimeGMT + (TimeCurrent() - TimeGMT());        
    
    if (TimeCurrent() - ParameterTimeBroker > PARAMETER_TIME_LIFE*86400) {
      strComment = StringConcatenate("Parameter set is out of date, create time["
            , TimeToStr(ParameterTimeBroker, TIME_DATE|TIME_MINUTES|TIME_SECONDS), "] lifetime[", IntegerToString(PARAMETER_TIME_LIFE), "]");
      Print(strComment);
      displayMessage(strComment, clrRed);
      displayMessage2("Change PARAMETER_TIME_LIFE to bigger value", clrRed);
      errorMessage = "[" + strComment + "]";
      isOutOfDate = True;
      return True; //Update is Okey but data is out of date
    };
    
    parameterName = "itemCount_time1";
    if (!getIntParameter(parameterName, itemCount_time1)) {
        getParameterFail(parameterName);
        return False;
    }
        
    parameterName = "itemCount_time2";
    if (!getIntParameter(parameterName, itemCount_time2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "itemCount_time3";
    if (!getIntParameter(parameterName, itemCount_time3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "itemCount_time4";
    if (!getIntParameter(parameterName, itemCount_time4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "itemCount_time6";
    if (!getIntParameter(parameterName, itemCount_time6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "itemCount_time7";
    if (!getIntParameter(parameterName, itemCount_time7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "itemCount_time8";
    if (!getIntParameter(parameterName, itemCount_time8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "AOI1";
    if (!getIntParameter(parameterName, AOI1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "AOI2";
    if (!getIntParameter(parameterName, AOI2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "AOI3";
    if (!getIntParameter(parameterName, AOI3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "AOI4";
    if (!getIntParameter(parameterName, AOI4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "AOI6";
    if (!getIntParameter(parameterName, AOI6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "AOI7";
    if (!getIntParameter(parameterName, AOI7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "AOI8";
    if (!getIntParameter(parameterName, AOI8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time1";
    if (!getIntParameter(parameterName, time1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time2";
    if (!getIntParameter(parameterName, time2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time3";
    if (!getIntParameter(parameterName, time3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time4";
    if (!getIntParameter(parameterName, time4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time6";
    if (!getIntParameter(parameterName, time6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time7";
    if (!getIntParameter(parameterName, time7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time8";
    if (!getIntParameter(parameterName, time8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time5";
    if (!getIntParameter(parameterName, time5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_period_time5";
    if (!getIntParameter(parameterName, ADX_period_time5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time25";
    if (!getIntParameter(parameterName, time25)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "AAA";
    if (!getIntParameter(parameterName, AAA)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ma_period_time25";
    if (!getIntParameter(parameterName, ma_period_time25)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time25";
    if (!getDoubleParameter(parameterName, Const_Buy_time25)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time25";
    if (!getDoubleParameter(parameterName, Const_Sell_time25)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time25_MAX";
    if (!getDoubleParameter(parameterName, Const_Buy_time25_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time25_MAX";
    if (!getDoubleParameter(parameterName, Const_Sell_time25_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time26";
    if (!getIntParameter(parameterName, time26)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "BBB";
    if (!getIntParameter(parameterName, BBB)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ma_period_time26";
    if (!getIntParameter(parameterName, ma_period_time26)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time26";
    if (!getDoubleParameter(parameterName, Const_Buy_time26)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time26";
    if (!getDoubleParameter(parameterName, Const_Sell_time26)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time26_MAX";
    if (!getDoubleParameter(parameterName, Const_Buy_time26_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time26_MAX";
    if (!getDoubleParameter(parameterName, Const_Sell_time26_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time27";
    if (!getIntParameter(parameterName, time27)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "CCC";
    if (!getIntParameter(parameterName, CCC)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ma_period_time27";
    if (!getIntParameter(parameterName, ma_period_time27)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time27";
    if (!getDoubleParameter(parameterName, Const_Buy_time27)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time27";
    if (!getDoubleParameter(parameterName, Const_Sell_time27)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time27_MAX";
    if (!getDoubleParameter(parameterName, Const_Buy_time27_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time27_MAX";
    if (!getDoubleParameter(parameterName, Const_Sell_time27_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time28";
    if (!getIntParameter(parameterName, time28)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "DDD";
    if (!getIntParameter(parameterName, DDD)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ma_period_time28";
    if (!getIntParameter(parameterName, ma_period_time28)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time28";
    if (!getDoubleParameter(parameterName, Const_Buy_time28)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time28";
    if (!getDoubleParameter(parameterName, Const_Sell_time28)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time28_MAX";
    if (!getDoubleParameter(parameterName, Const_Buy_time28_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time28_MAX";
    if (!getDoubleParameter(parameterName, Const_Sell_time28_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time31";
    if (!getIntParameter(parameterName, time31)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "FFF";
    if (!getIntParameter(parameterName, FFF)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ma_period_time31";
    if (!getIntParameter(parameterName, ma_period_time31)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time31";
    if (!getDoubleParameter(parameterName, Const_Buy_time31)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time31";
    if (!getDoubleParameter(parameterName, Const_Sell_time31)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time31_MAX";
    if (!getDoubleParameter(parameterName, Const_Buy_time31_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time31_MAX";
    if (!getDoubleParameter(parameterName, Const_Sell_time31_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time32";
    if (!getIntParameter(parameterName, time32)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "GGG";
    if (!getIntParameter(parameterName, GGG)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ma_period_time32";
    if (!getIntParameter(parameterName, ma_period_time32)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time32";
    if (!getDoubleParameter(parameterName, Const_Buy_time32)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time32";
    if (!getDoubleParameter(parameterName, Const_Sell_time32)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time32_MAX";
    if (!getDoubleParameter(parameterName, Const_Buy_time32_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time32_MAX";
    if (!getDoubleParameter(parameterName, Const_Sell_time32_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time33";
    if (!getIntParameter(parameterName, time33)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "HHH";
    if (!getIntParameter(parameterName, HHH)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ma_period_time33";
    if (!getIntParameter(parameterName, ma_period_time33)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time33";
    if (!getDoubleParameter(parameterName, Const_Buy_time33)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time33";
    if (!getDoubleParameter(parameterName, Const_Sell_time33)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time33_MAX";
    if (!getDoubleParameter(parameterName, Const_Buy_time33_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time33_MAX";
    if (!getDoubleParameter(parameterName, Const_Sell_time33_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time34";
    if (!getIntParameter(parameterName, time34)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "III";
    if (!getIntParameter(parameterName, III)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ma_period_time34";
    if (!getIntParameter(parameterName, ma_period_time34)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time34";
    if (!getDoubleParameter(parameterName, Const_Buy_time34)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time34";
    if (!getDoubleParameter(parameterName, Const_Sell_time34)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Buy_time34_MAX";
    if (!getDoubleParameter(parameterName, Const_Buy_time34_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_Sell_time34_MAX";
    if (!getDoubleParameter(parameterName, Const_Sell_time34_MAX)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time29";
    if (!getIntParameter(parameterName, time29)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "wpr_period_time29";
    if (!getIntParameter(parameterName, wpr_period_time29)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "wpr_conts_buy_time29";
    if (!getDoubleParameter(parameterName, wpr_conts_buy_time29)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "wpr_conts_sell_time29";
    if (!getDoubleParameter(parameterName, wpr_conts_sell_time29)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time30";
    if (!getIntParameter(parameterName, time30)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "wpr_period_time30";
    if (!getIntParameter(parameterName, wpr_period_time30)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "wpr_conts_buy_time30";
    if (!getDoubleParameter(parameterName, wpr_conts_buy_time30)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "wpr_conts_sell_time30";
    if (!getDoubleParameter(parameterName, wpr_conts_sell_time30)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "force_period_time1";
    if (!getIntParameter(parameterName, force_period_time1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "force_period_time2";
    if (!getIntParameter(parameterName, force_period_time2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "force_period_time3";
    if (!getIntParameter(parameterName, force_period_time3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "force_period_time4";
    if (!getIntParameter(parameterName, force_period_time4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "force_period_time6";
    if (!getIntParameter(parameterName, force_period_time6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "force_period_time7";
    if (!getIntParameter(parameterName, force_period_time7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "force_period_time8";
    if (!getIntParameter(parameterName, force_period_time8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_sell_time1";
    if (!getDoubleParameter(parameterName, Const_sell_time1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_sell_time2";
    if (!getDoubleParameter(parameterName, Const_sell_time2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_sell_time3";
    if (!getDoubleParameter(parameterName, Const_sell_time3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_sell_time4";
    if (!getDoubleParameter(parameterName, Const_sell_time4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_sell_time6";
    if (!getDoubleParameter(parameterName, Const_sell_time6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_sell_time7";
    if (!getDoubleParameter(parameterName, Const_sell_time7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_sell_time8";
    if (!getDoubleParameter(parameterName, Const_sell_time8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_buy_time1";
    if (!getDoubleParameter(parameterName, Const_buy_time1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_buy_time2";
    if (!getDoubleParameter(parameterName, Const_buy_time2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_buy_time3";
    if (!getDoubleParameter(parameterName, Const_buy_time3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_buy_time4";
    if (!getDoubleParameter(parameterName, Const_buy_time4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_buy_time6";
    if (!getDoubleParameter(parameterName, Const_buy_time6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_buy_time7";
    if (!getDoubleParameter(parameterName, Const_buy_time7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "Const_buy_time8";
    if (!getDoubleParameter(parameterName, Const_buy_time8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell1";
    if (!getDoubleParameter(parameterName, sl_sell1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell2";
    if (!getDoubleParameter(parameterName, sl_sell2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell3";
    if (!getDoubleParameter(parameterName, sl_sell3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell4";
    if (!getDoubleParameter(parameterName, sl_sell4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell5";
    if (!getDoubleParameter(parameterName, sl_sell5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell6";
    if (!getDoubleParameter(parameterName, sl_sell6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell7";
    if (!getDoubleParameter(parameterName, sl_sell7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell8";
    if (!getDoubleParameter(parameterName, sl_sell8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell9";
    if (!getDoubleParameter(parameterName, sl_sell9)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell10";
    if (!getDoubleParameter(parameterName, sl_sell10)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell11";
    if (!getDoubleParameter(parameterName, sl_sell11)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell12";
    if (!getDoubleParameter(parameterName, sl_sell12)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_sell13";
    if (!getDoubleParameter(parameterName, sl_sell13)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy1";
    if (!getDoubleParameter(parameterName, sl_buy1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy2";
    if (!getDoubleParameter(parameterName, sl_buy2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy3";
    if (!getDoubleParameter(parameterName, sl_buy3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy4";
    if (!getDoubleParameter(parameterName, sl_buy4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy5";
    if (!getDoubleParameter(parameterName, sl_buy5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy6";
    if (!getDoubleParameter(parameterName, sl_buy6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy7";
    if (!getDoubleParameter(parameterName, sl_buy7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy8";
    if (!getDoubleParameter(parameterName, sl_buy8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy9";
    if (!getDoubleParameter(parameterName, sl_buy9)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy10";
    if (!getDoubleParameter(parameterName, sl_buy10)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy11";
    if (!getDoubleParameter(parameterName, sl_buy11)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy12";
    if (!getDoubleParameter(parameterName, sl_buy12)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "sl_buy13";
    if (!getDoubleParameter(parameterName, sl_buy13)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy1";
    if (!getDoubleParameter(parameterName, tp_buy1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy2";
    if (!getDoubleParameter(parameterName, tp_buy2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy3";
    if (!getDoubleParameter(parameterName, tp_buy3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy4";
    if (!getDoubleParameter(parameterName, tp_buy4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy5";
    if (!getDoubleParameter(parameterName, tp_buy5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy6";
    if (!getDoubleParameter(parameterName, tp_buy6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy7";
    if (!getDoubleParameter(parameterName, tp_buy7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy8";
    if (!getDoubleParameter(parameterName, tp_buy8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy9";
    if (!getDoubleParameter(parameterName, tp_buy9)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy10";
    if (!getDoubleParameter(parameterName, tp_buy10)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_buy11";
    if (!getDoubleParameter(parameterName, tp_buy11)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell1";
    if (!getDoubleParameter(parameterName, tp_sell1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell2";
    if (!getDoubleParameter(parameterName, tp_sell2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell3";
    if (!getDoubleParameter(parameterName, tp_sell3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell4";
    if (!getDoubleParameter(parameterName, tp_sell4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell5";
    if (!getDoubleParameter(parameterName, tp_sell5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell6";
    if (!getDoubleParameter(parameterName, tp_sell6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell7";
    if (!getDoubleParameter(parameterName, tp_sell7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell8";
    if (!getDoubleParameter(parameterName, tp_sell8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell9";
    if (!getDoubleParameter(parameterName, tp_sell9)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell10";
    if (!getDoubleParameter(parameterName, tp_sell10)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "tp_sell11";
    if (!getDoubleParameter(parameterName, tp_sell11)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time11";
    if (!getIntParameter(parameterName, time11)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_BUY1";
    if (!getIntParameter(parameterName, waite_BUY1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_SELL1";
    if (!getIntParameter(parameterName, waite_SELL1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_BUY3";
    if (!getIntParameter(parameterName, waite_BUY3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_SELL3";
    if (!getIntParameter(parameterName, waite_SELL3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_BUY4";
    if (!getIntParameter(parameterName, waite_BUY4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_SELL4";
    if (!getIntParameter(parameterName, waite_SELL4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_BUY5";
    if (!getIntParameter(parameterName, waite_BUY5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_SELL5";
    if (!getIntParameter(parameterName, waite_SELL5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_BUY6";
    if (!getIntParameter(parameterName, waite_BUY6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "waite_SELL6";
    if (!getIntParameter(parameterName, waite_SELL6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time12";
    if (!getIntParameter(parameterName, time12)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time12";
    if (!getIntParameter(parameterName, band_period_time12)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time12";
    if (!getDoubleParameter(parameterName, siguma_time12)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time13";
    if (!getIntParameter(parameterName, time13)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time13";
    if (!getIntParameter(parameterName, band_period_time13)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time13";
    if (!getDoubleParameter(parameterName, siguma_time13)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time14";
    if (!getIntParameter(parameterName, time14)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time14";
    if (!getIntParameter(parameterName, band_period_time14)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time14";
    if (!getDoubleParameter(parameterName, siguma_time14)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time15";
    if (!getIntParameter(parameterName, time15)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time15";
    if (!getIntParameter(parameterName, band_period_time15)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time15";
    if (!getDoubleParameter(parameterName, siguma_time15)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time16";
    if (!getIntParameter(parameterName, time16)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time16";
    if (!getIntParameter(parameterName, band_period_time16)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time16";
    if (!getDoubleParameter(parameterName, siguma_time16)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time17";
    if (!getIntParameter(parameterName, time17)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time17";
    if (!getIntParameter(parameterName, band_period_time17)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time17";
    if (!getDoubleParameter(parameterName, siguma_time17)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time20";
    if (!getIntParameter(parameterName, time20)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time20";
    if (!getIntParameter(parameterName, band_period_time20)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time20";
    if (!getDoubleParameter(parameterName, siguma_time20)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time21";
    if (!getIntParameter(parameterName, time21)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time21";
    if (!getIntParameter(parameterName, band_period_time21)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time21";
    if (!getDoubleParameter(parameterName, siguma_time21)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time22";
    if (!getIntParameter(parameterName, time22)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "band_period_time22";
    if (!getIntParameter(parameterName, band_period_time22)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "siguma_time22";
    if (!getDoubleParameter(parameterName, siguma_time22)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time18";
    if (!getIntParameter(parameterName, time18)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "time19";
    if (!getIntParameter(parameterName, time19)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const1";
    if (!getDoubleParameter(parameterName, ADX_time5_Const1)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const2";
    if (!getDoubleParameter(parameterName, ADX_time5_Const2)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const3";
    if (!getDoubleParameter(parameterName, ADX_time5_Const3)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const4";
    if (!getDoubleParameter(parameterName, ADX_time5_Const4)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const5";
    if (!getDoubleParameter(parameterName, ADX_time5_Const5)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const6";
    if (!getDoubleParameter(parameterName, ADX_time5_Const6)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const7";
    if (!getDoubleParameter(parameterName, ADX_time5_Const7)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const8";
    if (!getDoubleParameter(parameterName, ADX_time5_Const8)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const9";
    if (!getDoubleParameter(parameterName, ADX_time5_Const9)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "ADX_time5_Const10";
    if (!getDoubleParameter(parameterName, ADX_time5_Const10)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "BuyEntryMaxNumber";
    if (!getIntParameter(parameterName, BuyEntryMaxNumber)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "SellEntryMaxNumber";
    if (!getIntParameter(parameterName, SellEntryMaxNumber)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "TakeProfitDefaultBuy";
    if (!getIntParameter(parameterName, TakeProfitDefaultBuy)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "TakeProfitDefaultSell";
    if (!getIntParameter(parameterName, TakeProfitDefaultSell)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "StopLossDefaultBuy";
    if (!getIntParameter(parameterName, StopLossDefaultBuy)) {
        getParameterFail(parameterName);
        return False;
    }
    
    parameterName = "StopLossDefaultSell";
    if (!getIntParameter(parameterName, StopLossDefaultSell)) {
        getParameterFail(parameterName);
        return False;
    }
    
    writeString("FINISH");    
    Close(client);
    //updatedFlag = True;
    return True;
}

void getParameterFail(string parameterName) {
   //Comment(StringConcatenate(EA_NAME, "Could not get value for parameter ", parameterName));
   displayMessage2(StringConcatenate(EA_NAME, "Could not get value for parameter ", parameterName), clrBlue);
   Close(client);
}

bool getIntParameter(string parameterName, int &value) {
   int res = writeString(parameterName);
   if (res <= 0) return False;
   string parameterVal = "";
   res = readString(parameterVal);
   if (res <= 0) return False;
   value = StringToInteger(parameterVal);
   //PrintFormat("%s=%d", parameterName, value);
   return True;
}

bool getDoubleParameter(string parameterName, double &value) {
   int res = writeString(parameterName);
   if (res <= 0) return False;
   string parameterVal = "";
   res = readString(parameterVal);
   if (res <= 0) return False;
   value = StringToDouble(parameterVal);
   //PrintFormat("%s=%.5f", parameterName, value);
   return True;
}


/*
return 0 if socket is not open
return -1 if there is an error or connection is closed
return > 0 => get data successfull 
*/  
int readString(string &receivedString) // Receive until the peer closes the connection
{
   uchar rdata[];
   if(client==INVALID_SOCKET) {
      //Print("trace 1");
      receivedString = "";
      return 0; // if the socket is not open   
   }
   char rbuf[512];
   int rlen=512; int r=0,res=0;
   bool retry = False;
   int maxRetry = 100;
   int retryCount = 0;
   do
     {
      retry = False;
      res=recv(client,rbuf,rlen,0);
      if(res<0)
        {
         int err=WSAGetLastError();
         if (err == WSAEWOULDBLOCK) {            
            Sleep(10);
            retry = True;
            retryCount++;
            if (retryCount == maxRetry) {
               PrintFormat("Resource temporaly unavailable, reach max retry(%d)", maxRetry);
            }
            continue;
         }
         //Print("-Receive failed error: "+string(err)+" "+WSAErrorDescript(err));
         Print("-Receive failed error: "+string(err)+" "+WSAErrorDescript(err)); 
         CloseClean();
         return -1;         
         break;         
        }
      //printf("Received %s", CharArrayToString(rbuf));
      if(res==0 && r==0) { Print("-Receive. connection closed"); CloseClean(); return -1; }
      r+=res; ArrayCopy(rdata, rbuf ,ArraySize(rdata),0,res);
     }
     while((res>0 && res>=rlen) || (retry && (retryCount < maxRetry)));
     receivedString = CharArrayToString(rdata);
     return r;
}


/*
return 0 if socket is not open
return -1 if there is an error or connection is closed
return > 0 => send data successfull 
*/  
int writeString(string strData)
{
    uchar data[];      
    StringToCharArray(strData, data);
    int len = ArraySize(data);
    return send(client, data, len-1, 0);//send request
}

int Receive(uchar &rdata[]) // Receive until the peer closes the connection
{
   if(client==INVALID_SOCKET) {
      Print("trace 1");
      return 0; // if the socket is not open   
   }
   char rbuf[512]; int rlen=512; 
   int r=0,res=0;
   do
     {
      res=recv(client,rbuf,rlen,0);
      if(res<0)
        {
         Print("trace 2");         
         int err=WSAGetLastError();
         Print("-Receive failed error: "+string(err)+" "+WSAErrorDescript(err));
         if(err!=WSAEWOULDBLOCK) { Print("-Receive failed error: "+string(err)+" "+WSAErrorDescript(err)); CloseClean(); return -1; }
         break;
        }
      printf("Received %s[%d]", CharArrayToString(rbuf), res);
      if(res==0 && r==0) { Print("-Receive. connection closed"); CloseClean(); return -1; }
      r+=res; ArrayCopy(rdata,rbuf,ArraySize(rdata),0,res);
     }
   while(res>0 && res>=rlen);
   return r;
}



void Close(SOCKET &asock){// close one socket
    if(asock==INVALID_SOCKET) return;
    if(shutdown(asock,SD_BOTH)==SOCKET_ERROR) Print("-Shutdown failed error: "+WSAErrorDescript(WSAGetLastError()));
    closesocket(asock);
    asock=INVALID_SOCKET;
}

void CloseClean() // close socket
{
   if(client!=INVALID_SOCKET)
     {
      if(shutdown(client, SD_BOTH)==SOCKET_ERROR) Print("-Shutdown failed error: "+WSAErrorDescript(WSAGetLastError()));
      closesocket(client); client=INVALID_SOCKET;
     }
   
   WSACleanup();
   Print("closed socket");
}
  
bool StartClient(string addr, ushort port){
   string strComment = "";
   strComment = StringConcatenate(EA_NAME, "Connecting to ", addr, ":", IntegerToString(port));
   
   PrintFormat(strComment);   
   
   // initialize the library
   int res=0;
   char wsaData[]; ArrayResize(wsaData, sizeof(WSAData));
   res=WSAStartup(MAKEWORD(2,2), wsaData);
   if (res!=0) {
      Print("-WSAStartup failed error: "+string(res)); 
      strComment = StringConcatenate(EA_NAME, "WSAStartup failed ", addr, ":", IntegerToString(port));
      //Comment(strComment);
      displayMessage(strComment, clrRed);
      return false;       
   }

   // create a socket
   client=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
   if(client==INVALID_SOCKET) {
      Print("-Create failed error: "+WSAErrorDescript(WSAGetLastError())); 
      CloseClean();
      strComment = StringConcatenate(EA_NAME, "Create socket failed ", addr, ":", IntegerToString(port));
      //Comment(strComment);      
      displayMessage(strComment, clrRed);
      return false;
   }
   /*
   // connect to server
   char ch[]; StringToCharArray(addr,ch);
   sockaddr_in addrin;
   addrin.sin_family=AF_INET;
   addrin.sin_addr=inet_addr(ch);
   addrin.sin_port=htons(port);
   */
   // connect to server
   char ch[]; StringToCharArray(addr,ch);
   sockaddr_in addrin;
   addrin.sin_family=AF_INET;
   //addrin.sin_addr=inet_addr(ch);
   addrin.sin_addr.u.S_addr=inet_addr(ch);   
   addrin.sin_port=htons(port);
   
   /*   
   //ref_sockaddr ref=(ref_sockaddr)addrin;
   ref_sockaddr ref; //=(ref_sockaddr)addrin;
   res=connect(client,ref.ref,sizeof(addrin));
   */
   
   //ref_sockaddr ref=(ref_sockaddr)addrin;
   ref_sockaddr ref; ref.in=addrin;
   //Print("mark0");
   res=connect(client,ref.ref,sizeof(addrin));   
   //Print("mark1");
   if(res==SOCKET_ERROR)
     {
      int err=WSAGetLastError();
      if(err!=WSAEISCONN) {
         Print("-Connect failed error: "+WSAErrorDescript(err)); CloseClean();
         strComment = StringConcatenate(EA_NAME, "Could not connect to ", addr, ":", IntegerToString(port));
         //Comment(strComment);
         displayMessage(strComment, clrRed);
         return false;
      }
     }
   //Print("mark2");
   //set to nonblocking mode
   int non_block=1;
   res=ioctlsocket(client,(int)FIONBIO,non_block);
   //Print("mark3");
   if(res!=NO_ERROR) {
      Print("ioctlsocket failed error: "+string(res));
      CloseClean(); 
      strComment = StringConcatenate(EA_NAME, "Could not connect to ", addr, ":", IntegerToString(port), " ioctlsocket failed");
      //Comment(strComment);      
      displayMessage(strComment, clrRed);
      return false; 
   }
      
   Print("connected OK");
   strComment = StringConcatenate(EA_NAME, "Connected to ", addr, ":", IntegerToString(port));
   //Comment(strComment);
   displayMessage(strComment, clrRed);
   return True;
}

//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init() {
    SYMBOL_CODE = StringTrimRight(StringTrimLeft(SYMBOL_CODE));
    StringToUpper(SYMBOL_CODE);
    //Checking for unconvetional Point digits number
    if (Point == 0.00001) pipValue = 0.0001; //5 digits
    else if (Point == 0.001) pipValue = 0.01; //3 digits
    ///////////////////////////////////////////////////////////
    else if (Point == 0.0001) pipValue = Point; //4 digits
    else if (Point == 0.01) pipValue = Point; //2 digits
    else pipValue = Point; //Normal    
    MathSrand(GetTickCount());    
    if (updateParameter()) {
      TRADE_DISABLE = FALSE;
      LastRetryTime = TimeCurrent();
      updatedFlag = True;
      clearAllObject();
    }
    findMinTimeFrame();    
    return(0);
}

  

bool isOutOfDateParameter() {
    if (TimeCurrent() - ParameterTimeBroker > PARAMETER_TIME_LIFE*86400) {
      string strComment = StringConcatenate("Parameter set is out of date, create time["
            , TimeToStr(ParameterTimeBroker, TIME_DATE|TIME_MINUTES|TIME_SECONDS), "]");
      //Comment(strComment);
      displayMessage(strComment, clrRed);
      displayMessage2("Change PARAMETER_TIME_LIFE to bigger value", clrRed);
      Print(strComment);
      //PrintFormat("Parameter set is out of date, create time[%s] lifetime[%d]"
      //      , TimeToStr(ParameterTimeBroker, TIME_DATE|TIME_MINUTES|TIME_SECONDS), PARAMETER_TIME_LIFE);
      
      return True;
    };
    return False;
}  
void countBuySellPosition() {
    gCountBuy = 0;
    gCountSell = 0;
    //オーダーチェック Order check
    for(int cnt=0; cnt<OrdersTotal(); cnt++)
    {
        OrderSelect(cnt, SELECT_BY_POS);
        if(OrderMagicNumber() == MAGIC_NUMBER)
        {
            if(OrderSymbol() == Symbol())
            {
               if( OrderType() == OP_SELL )
               {
                    gCountSell = gCountSell + 1;
                } else if( OrderType() == OP_BUY ) {
                    gCountBuy = gCountBuy + 1;
                };
            };
        };    
    };        
}  
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
   //----
   CloseClean();
   Comment("");
   clearAllObject();
   return(0);
  }
  
bool isCheckPointTime() {
    if (iTime(NULL, minTimeFrame, 0) != lastTimeCheckPoint) {
        lastTimeCheckPoint = iTime(NULL, minTimeFrame, 0);
        return true;        
    }
}  

  
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
   
   if (!updatedFlag) {
      if (TimeCurrent() - LastRetryTime <= WAIT_BEFORE_RETRY*60) {
         string strComment = StringConcatenate("Update parameter failed at ["
            , TimeToStr(LastRetryTime, TIME_MINUTES|TIME_MINUTES|TIME_SECONDS)
            , "] Next retry at[", TimeToStr(LastRetryTime + WAIT_BEFORE_RETRY*60, TIME_MINUTES|TIME_MINUTES|TIME_SECONDS), "]");
         displayMessage(strComment, clrRed);   
         displayMessage2(errorMessage, clrRed);
         return 0;
      }
      //Retry   
      if (updateParameter()) {
         TRADE_DISABLE = False;         
         updatedFlag = True;
         clearAllObject();
      } else {
         TRADE_DISABLE = True;
         updatedFlag = False;
      };
      return 0;
   }
   
   if (isOutOfDateParameter()) {
      isOutOfDate = True;
      if (TRADE_DISABLE == False) {
         TRADE_DISABLE = True;
         strComment = StringConcatenate("Parameter set is out of date, create time[", 
            TimeToStr(ParameterTimeBroker, TIME_DATE|TIME_MINUTES|TIME_SECONDS), "] lifetime[", IntegerToString(PARAMETER_TIME_LIFE), "]");
         Print(strComment);
         displayMessage(strComment, clrRed);
         displayMessage2("Change PARAMETER_TIME_LIFE to bigger value", clrRed);
      };      
      if (TimeCurrent() - LastRetryTime <= WAIT_BEFORE_RETRY*60) {
         return 0;
      };
      if (updateParameter()) {
         TRADE_DISABLE = False;
         clearAllObject();
      } else {
         TRADE_DISABLE = True;
      };
   };
   
   if (TRADE_DISABLE) {
      return 0;
   }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    int cnt;        //カウント用バッファ
    int Ticket;     //チケット番号
    int n_Order;    //オーダー番号を入れる変数
                  
    double gn_Count=0;
    double gd_Average=0;
    double d_Lots=0;
    
    n_Order=-1; //初期化
    
    double Average_Price_NOW_OP_SELL = 0;
    double Average_Price_NOW_OP_BUY=0.0000;    
    double dBuyLots = 0, dSellLots = 0;

    
    //オーダーチェック Order check
    for(cnt=0;cnt<OrdersTotal();cnt++)
    {
        OrderSelect(cnt,SELECT_BY_POS);
                
        if(OrderMagicNumber() == MAGIC_NUMBER)
        {
            if(OrderSymbol() == Symbol())
            {
               if( OrderType() == OP_SELL )
               {
                    //n_Order=cnt;
                    Average_Price_NOW_OP_SELL = Average_Price_NOW_OP_SELL + OrderOpenPrice()*OrderLots();
                    dSellLots = dSellLots + OrderLots();
                    //gd_Average=gd_Average+OrderOpenPrice()*OrderLots();
                    //d_Lots=d_Lots+OrderLots();
                    //gn_Count++;
                } else if( OrderType() == OP_BUY ) {
                    Average_Price_NOW_OP_BUY = Average_Price_NOW_OP_BUY + OrderOpenPrice()*OrderLots();
                    dBuyLots = dBuyLots + OrderLots();
                };
            };
        };    
    };

    if (dSellLots > 0) Average_Price_NOW_OP_SELL = Average_Price_NOW_OP_SELL/dSellLots;
    if (dBuyLots > 0) Average_Price_NOW_OP_BUY = Average_Price_NOW_OP_BUY/dBuyLots;
    
    checkEndCloseTrades(Average_Price_NOW_OP_BUY, Average_Price_NOW_OP_SELL);

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    double spread_now=(Ask-Bid)/(pipValue);
    
    //COMMENT
    datetime l_t = TimeLocal();
    string l_t_str = TimeYear(l_t)+"/"+TimeMonth(l_t)+"/"+TimeDay(l_t)+"<"+TimeHour(l_t)+":"+TimeMinute(l_t)+":"+TimeSeconds(l_t)+">";
    string s_t_str = Year()+"/"+Month()+"/"+Day()+"<"+Hour()+":"+Minute()+":"+Seconds()+">";
    
    Comment("Parameter update time: ", TimeToStr(ParameterTimeBroker, TIME_DATE|TIME_MINUTES)
             ,"\n\n","KnowledgeLibrary for Happiness Limited Company."
             ,"\n\n",Symbol()
             ,"\n\n","FX Server Time : ", s_t_str
             ,"\n\n", "PC Local Time : ", l_t_str
             ,"\n\n","SPREAD: ",spread_now," Pips"
             );

    //if(Time[0] == prevtime) return(0);
    //prevtime = Time[0];
    if (!isCheckPointTime()) return 0;
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // DETERMINE sl_buy2, tp_buy1, sl_sell2, tp_sell1
    double iADXPeriodTime5 = iADX(NULL,time5,ADX_period_time5,PRICE_WEIGHTED,MODE_MAIN,1);
    
    if ( iADXPeriodTime5 <= ADX_time5_Const1 )
    {
        sl_buy2=sl_buy4;
        tp_buy1=tp_buy2;
        sl_sell2=sl_sell4;
        tp_sell1=tp_sell2;
    } else if ( iADXPeriodTime5 > ADX_time5_Const1
            && iADXPeriodTime5 <= ADX_time5_Const2 ){
        sl_buy2=sl_buy5;
        tp_buy1=tp_buy3;
        sl_sell2=sl_sell5;
        tp_sell1=tp_sell3;
    } else if ( iADXPeriodTime5 > ADX_time5_Const2
            && iADXPeriodTime5 <= ADX_time5_Const3) {
        sl_buy2=sl_buy6;
        tp_buy1=tp_buy4;
        sl_sell2=sl_sell6;
        tp_sell1=tp_sell4;
    } else if ( iADXPeriodTime5 > ADX_time5_Const3
            && iADXPeriodTime5 <= ADX_time5_Const4) {
        sl_buy2=sl_buy7;
        tp_buy1=tp_buy5;
        sl_sell2=sl_sell7;
        tp_sell1=tp_sell5;
    } else if ( iADXPeriodTime5 > ADX_time5_Const4
            && iADXPeriodTime5 <= ADX_time5_Const5){
        sl_buy2=sl_buy8;
        tp_buy1=tp_buy6;
        sl_sell2=sl_sell8;
        tp_sell1=tp_sell6;
    } else if ( iADXPeriodTime5 > ADX_time5_Const5
            && iADXPeriodTime5 <= ADX_time5_Const6) {
        sl_buy2=sl_buy9;
        tp_buy1=tp_buy7;
        sl_sell2=sl_sell9;
        tp_sell1=tp_sell7;
    } else if ( iADXPeriodTime5 > ADX_time5_Const6
            && iADXPeriodTime5 <= ADX_time5_Const7
    ) {
        sl_buy2=sl_buy10;
        tp_buy1=tp_buy8;
        sl_sell2=sl_sell10;
        tp_sell1=tp_sell8;
    } else if ( iADXPeriodTime5 > ADX_time5_Const7
            && iADXPeriodTime5 <= ADX_time5_Const8) {
        sl_buy2=sl_buy11;
        tp_buy1=tp_buy9;
        sl_sell2=sl_sell11;
        tp_sell1=tp_sell9;
    } else if ( iADXPeriodTime5 > ADX_time5_Const8
            && iADXPeriodTime5 <= ADX_time5_Const9) {
        sl_buy2=sl_buy12;
        tp_buy1=tp_buy10;
        sl_sell2=sl_sell12;
        tp_sell1=tp_sell10;
    } else if ( iADXPeriodTime5 > ADX_time5_Const9
            && iADXPeriodTime5 <= ADX_time5_Const10) {
        sl_buy2=sl_buy13;
        tp_buy1=tp_buy11;
        sl_sell2=sl_sell13;
        tp_sell1=tp_sell11;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    double Hull_MA_time25_High =AAA*( iMA(NULL,time25,MathRound(ma_period_time25/2.00),0,MODE_LWMA,PRICE_HIGH,1))-(AAA-1)*iMA(NULL,time25,MathRound(ma_period_time25/2.00)*2,0,MODE_LWMA,PRICE_HIGH,1);
    double Hull_MA_time25_Low  =AAA*( iMA(NULL,time25,MathRound(ma_period_time25/2.00),0,MODE_LWMA,PRICE_LOW,1)) -(AAA-1)*iMA(NULL,time25,MathRound(ma_period_time25/2.00)*2,0,MODE_LWMA,PRICE_LOW,1);
    double Hull_MA_time25_Open =AAA*( iMA(NULL,time25,MathRound(ma_period_time25/2.00),0,MODE_LWMA,PRICE_OPEN,1)) -(AAA-1)*iMA(NULL,time25,MathRound(ma_period_time25/2.00)*2,0,MODE_LWMA,PRICE_OPEN,1);

    double HO_OL_time25=0.00;
    double OL_HO_time25=0.00;

    if( (Hull_MA_time25_Open-Hull_MA_time25_Low)==0 || (Hull_MA_time25_High-Hull_MA_time25_Open)==0 )
    {
         HO_OL_time25=0.00;
         OL_HO_time25=0.00;
    }
    else
    {
         HO_OL_time25=(Hull_MA_time25_High-Hull_MA_time25_Open)/(Hull_MA_time25_Open-Hull_MA_time25_Low);
         OL_HO_time25=(Hull_MA_time25_Open-Hull_MA_time25_Low) /(Hull_MA_time25_High-Hull_MA_time25_Open);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    double Hull_MA_time26_High =BBB*( iMA(NULL,time26,MathRound(ma_period_time26/2.00),0,MODE_LWMA,PRICE_HIGH,1))-(BBB-1)*iMA(NULL,time26,MathRound(ma_period_time26/2.00)*2,0,MODE_LWMA,PRICE_HIGH,1);
    double Hull_MA_time26_Low  =BBB*( iMA(NULL,time26,MathRound(ma_period_time26/2.00),0,MODE_LWMA,PRICE_LOW,1)) -(BBB-1)*iMA(NULL,time26,MathRound(ma_period_time26/2.00)*2,0,MODE_LWMA,PRICE_LOW,1);
    double Hull_MA_time26_Open =BBB*( iMA(NULL,time26,MathRound(ma_period_time26/2.00),0,MODE_LWMA,PRICE_OPEN,1)) -(BBB-1)*iMA(NULL,time26,MathRound(ma_period_time26/2.00)*2,0,MODE_LWMA,PRICE_OPEN,1);

    double HO_OL_time26=0.00;
    double OL_HO_time26=0.00;
    
    if( (Hull_MA_time26_Open-Hull_MA_time26_Low)==0 || (Hull_MA_time26_High-Hull_MA_time26_Open)==0 )
    {
        HO_OL_time26=0.00;
        OL_HO_time26=0.00;
    }
    else
    {
        HO_OL_time26=(Hull_MA_time26_High-Hull_MA_time26_Open)/(Hull_MA_time26_Open-Hull_MA_time26_Low);
        OL_HO_time26=(Hull_MA_time26_Open-Hull_MA_time26_Low) /(Hull_MA_time26_High-Hull_MA_time26_Open);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    double Hull_MA_time27_High =CCC*( iMA(NULL,time27,MathRound(ma_period_time27/2.00),0,MODE_LWMA,PRICE_HIGH,1))-(CCC-1)*iMA(NULL,time27,MathRound(ma_period_time27/2.00)*2,0,MODE_LWMA,PRICE_HIGH,1);
    double Hull_MA_time27_Low  =CCC*( iMA(NULL,time27,MathRound(ma_period_time27/2.00),0,MODE_LWMA,PRICE_LOW,1)) -(CCC-1)*iMA(NULL,time27,MathRound(ma_period_time27/2.00)*2,0,MODE_LWMA,PRICE_LOW,1);
    double Hull_MA_time27_Open =CCC*( iMA(NULL,time27,MathRound(ma_period_time27/2.00),0,MODE_LWMA,PRICE_OPEN,1)) -(CCC-1)*iMA(NULL,time27,MathRound(ma_period_time27/2.00)*2,0,MODE_LWMA,PRICE_OPEN,1);
    
    double HO_OL_time27=0.00;
    double OL_HO_time27=0.00;
    
    if( (Hull_MA_time27_Open-Hull_MA_time27_Low)==0 || (Hull_MA_time27_High-Hull_MA_time27_Open)==0 )
    {
        HO_OL_time27=0.00;
        OL_HO_time27=0.00;
    }
    else
    {
        HO_OL_time27=(Hull_MA_time27_High-Hull_MA_time27_Open)/(Hull_MA_time27_Open-Hull_MA_time27_Low);
        OL_HO_time27=(Hull_MA_time27_Open-Hull_MA_time27_Low) /(Hull_MA_time27_High-Hull_MA_time27_Open);
    }
    
   
    double Hull_MA_time28_High =DDD*( iMA(NULL,time28,MathRound(ma_period_time28/2.00),0,MODE_LWMA,PRICE_HIGH,1))-(DDD-1)*iMA(NULL,time28,MathRound(ma_period_time28/2.00)*2,0,MODE_LWMA,PRICE_HIGH,1);
    double Hull_MA_time28_Low  =DDD*( iMA(NULL,time28,MathRound(ma_period_time28/2.00),0,MODE_LWMA,PRICE_LOW,1)) -(DDD-1)*iMA(NULL,time28,MathRound(ma_period_time28/2.00)*2,0,MODE_LWMA,PRICE_LOW,1);
    double Hull_MA_time28_Open =DDD*( iMA(NULL,time28,MathRound(ma_period_time28/2.00),0,MODE_LWMA,PRICE_OPEN,1)) -(DDD-1)*iMA(NULL,time28,MathRound(ma_period_time28/2.00)*2,0,MODE_LWMA,PRICE_OPEN,1);

    double HO_OL_time28=0.00;
    double OL_HO_time28=0.00;
    
    if( (Hull_MA_time28_Open-Hull_MA_time28_Low)==0 || (Hull_MA_time28_High-Hull_MA_time28_Open)==0 )
    {
        HO_OL_time28=0.00;
        OL_HO_time28=0.00;
    }
    else
    {
        HO_OL_time28=(Hull_MA_time28_High-Hull_MA_time28_Open)/(Hull_MA_time28_Open-Hull_MA_time28_Low);
        OL_HO_time28=(Hull_MA_time28_Open-Hull_MA_time28_Low) /(Hull_MA_time28_High-Hull_MA_time28_Open);
    }

    double Hull_MA_time31_High =FFF*( iMA(NULL,time31,MathRound(ma_period_time31/2.00),0,MODE_LWMA,PRICE_HIGH,1))-(FFF-1)*iMA(NULL,time31,MathRound(ma_period_time31/2.00)*2,0,MODE_LWMA,PRICE_HIGH,1);
    double Hull_MA_time31_Low  =FFF*( iMA(NULL,time31,MathRound(ma_period_time31/2.00),0,MODE_LWMA,PRICE_LOW,1)) -(FFF-1)*iMA(NULL,time31,MathRound(ma_period_time31/2.00)*2,0,MODE_LWMA,PRICE_LOW,1);
    double Hull_MA_time31_Open =FFF*( iMA(NULL,time31,MathRound(ma_period_time31/2.00),0,MODE_LWMA,PRICE_OPEN,1)) -(FFF-1)*iMA(NULL,time31,MathRound(ma_period_time31/2.00)*2,0,MODE_LWMA,PRICE_OPEN,1);

    double HO_OL_time31=0.00;
    double OL_HO_time31=0.00;

    if( (Hull_MA_time31_Open-Hull_MA_time31_Low)==0 || (Hull_MA_time31_High-Hull_MA_time31_Open)==0 )
    {
        HO_OL_time31=0.00;
        OL_HO_time31=0.00;
    }
    else
    {
        HO_OL_time31=(Hull_MA_time31_High-Hull_MA_time31_Open)/(Hull_MA_time31_Open-Hull_MA_time31_Low);
        OL_HO_time31=(Hull_MA_time31_Open-Hull_MA_time31_Low) /(Hull_MA_time31_High-Hull_MA_time31_Open);
    }
    

    ///////////////////////////////////////////////////////////////////////////////////////////////
    double Hull_MA_time32_High =GGG*( iMA(NULL,time32,MathRound(ma_period_time32/2.00),0,MODE_LWMA,PRICE_HIGH,1))-(GGG-1)*iMA(NULL,time32,MathRound(ma_period_time32/2.00)*2,0,MODE_LWMA,PRICE_HIGH,1);
    double Hull_MA_time32_Low  =GGG*( iMA(NULL,time32,MathRound(ma_period_time32/2.00),0,MODE_LWMA,PRICE_LOW,1)) -(GGG-1)*iMA(NULL,time32,MathRound(ma_period_time32/2.00)*2,0,MODE_LWMA,PRICE_LOW,1);
    double Hull_MA_time32_Open =GGG*( iMA(NULL,time32,MathRound(ma_period_time32/2.00),0,MODE_LWMA,PRICE_OPEN,1)) -(GGG-1)*iMA(NULL,time32,MathRound(ma_period_time32/2.00)*2,0,MODE_LWMA,PRICE_OPEN,1);

    double HO_OL_time32=0.00;
    double OL_HO_time32=0.00;
    
    if( (Hull_MA_time32_Open-Hull_MA_time32_Low)==0 || (Hull_MA_time32_High-Hull_MA_time32_Open)==0 )
    {
        HO_OL_time32=0.00;
        OL_HO_time32=0.00;
    } else {
        HO_OL_time32=(Hull_MA_time32_High-Hull_MA_time32_Open)/(Hull_MA_time32_Open-Hull_MA_time32_Low);
        OL_HO_time32=(Hull_MA_time32_Open-Hull_MA_time32_Low) /(Hull_MA_time32_High-Hull_MA_time32_Open);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    double Hull_MA_time33_High =HHH*( iMA(NULL,time33,MathRound(ma_period_time33/2.00),0,MODE_LWMA,PRICE_HIGH,1))-(HHH-1)*iMA(NULL,time33,MathRound(ma_period_time33/2.00)*2,0,MODE_LWMA,PRICE_HIGH,1);
    double Hull_MA_time33_Low  =HHH*( iMA(NULL,time33,MathRound(ma_period_time33/2.00),0,MODE_LWMA,PRICE_LOW,1)) -(HHH-1)*iMA(NULL,time33,MathRound(ma_period_time33/2.00)*2,0,MODE_LWMA,PRICE_LOW,1);
    double Hull_MA_time33_Open =HHH*( iMA(NULL,time33,MathRound(ma_period_time33/2.00),0,MODE_LWMA,PRICE_OPEN,1)) -(HHH-1)*iMA(NULL,time33,MathRound(ma_period_time33/2.00)*2,0,MODE_LWMA,PRICE_OPEN,1);
    
    double HO_OL_time33=0.00;
    double OL_HO_time33=0.00;
    
    if( (Hull_MA_time33_Open-Hull_MA_time33_Low)==0 || (Hull_MA_time33_High-Hull_MA_time33_Open)==0 )
    {
        HO_OL_time33=0.00;
        OL_HO_time33=0.00;
    }
    else
    {
        HO_OL_time33=(Hull_MA_time33_High-Hull_MA_time33_Open)/(Hull_MA_time33_Open-Hull_MA_time33_Low);
        OL_HO_time33=(Hull_MA_time33_Open-Hull_MA_time33_Low) /(Hull_MA_time33_High-Hull_MA_time33_Open);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    double Hull_MA_time34_High =III*( iMA(NULL,time34,MathRound(ma_period_time34/2.00),0,MODE_LWMA,PRICE_HIGH,1))-(III-1)*iMA(NULL,time34,MathRound(ma_period_time34/2.00)*2,0,MODE_LWMA,PRICE_HIGH,1);
    double Hull_MA_time34_Low  =III*( iMA(NULL,time34,MathRound(ma_period_time34/2.00),0,MODE_LWMA,PRICE_LOW,1)) -(III-1)*iMA(NULL,time34,MathRound(ma_period_time34/2.00)*2,0,MODE_LWMA,PRICE_LOW,1);
    double Hull_MA_time34_Open =III*( iMA(NULL,time34,MathRound(ma_period_time34/2.00),0,MODE_LWMA,PRICE_OPEN,1)) -(III-1)*iMA(NULL,time34,MathRound(ma_period_time34/2.00)*2,0,MODE_LWMA,PRICE_OPEN,1);
    
    double HO_OL_time34=0.00;
    double OL_HO_time34=0.00;
    
    if( (Hull_MA_time34_Open-Hull_MA_time34_Low)==0 || (Hull_MA_time34_High-Hull_MA_time34_Open)==0 )
    {
        HO_OL_time34=0.00;
        OL_HO_time34=0.00;
    }
    else
    {
        HO_OL_time34=(Hull_MA_time34_High-Hull_MA_time34_Open)/(Hull_MA_time34_Open-Hull_MA_time34_Low);
        OL_HO_time34=(Hull_MA_time34_Open-Hull_MA_time34_Low) /(Hull_MA_time34_High-Hull_MA_time34_Open);
    }
    
    
    ///////////////////////////////////////////////////////////////////////////////////////////////
    double SL = 0, ecnSL = 0;
    if (AccountFreeMargin() < (2*LOT_SIZE*1000)) return(0);
    

    //----
    if(IsTradeAllowed()) {
       RefreshRates();
       spread = MarketInfo(Symbol(), MODE_SPREAD);
    } else {
        //prevtime = Time[1];
        lastTimeCheckPoint = iTime(NULL, minTimeFrame, 1);
        return(0);
    }
    
    int ticket = -1;
    // check for opened position
    int total = OrdersTotal();   

    //----
    double averagePriceInTimeFrame11 = averageCandlestick(time11, 1);
    
    //Handle hedge order (place opposite order when others exist)
    for(int i = 0; i < total; i++) 
     {
       SL = 0; ecnSL = 0;
       OrderSelect(i, SELECT_BY_POS, MODE_TRADES); 
       // check for symbol & magic number
       if(OrderSymbol() == Symbol() && OrderMagicNumber() == MAGIC_NUMBER) 
         {
            int prevticket = OrderTicket();           
            ///////////////// long position is opened//////////////////////////////////////////////////////////////////
            ///売りのドテンの可能性をチェックする
            ///売りのドテンの可能性をチェックする
            ///売りのドテンの可能性をチェックする
            ///////////////// long position is opened//////////////////////////////////////////////////////////////////

           if(OrderType() == OP_BUY) 
             {
               if( (averagePriceInTimeFrame11  - Average_Price_NOW_OP_BUY  >= 0)
                    && (Bid - sl_buy2 * pipValue) >= OrderStopLoss()) {
                    if ( (averageCandlestick(time18,1)  >= averageCandlestick(time18, 2))
                         || (averageCandlestick(time19,1)  >=  averageCandlestick(time19, 2))
                         || ((iHigh(NULL,time19,1)+iLow(NULL,time19,1))/2  >= (iHigh(NULL,time19,2)+iLow(NULL,time19,2))/2 )
                         || ((iHigh(NULL,time18,1)+iLow(NULL,time18,1)) /2 >= ( iHigh(NULL,time18,2)+iLow(NULL,time18,2))/2 )
                         ) {
                        //bool OrderModify( int ticket, double price, double stoploss, double takeprofit, datetime expiration, color Color=CLR_NONE)
                        if(!OrderModify(OrderTicket(), OrderOpenPrice(), Bid - sl_buy2 * pipValue,Bid + tp_buy1 * pipValue, 0, clrWheat)) 
                        {
                            Sleep(30000);
                            //prevtime = Time[1];
                            lastTimeCheckPoint = iTime(NULL, minTimeFrame, 1);
                        } 
                    }
                };
             }
            ////////////////////// short position is opened//////////////////////////////////////////////
            ///買いのドテンの可能性をチェックする To check the possibility of buying Doten
            ///買いのドテンの可能性をチェックする
            ///買いのドテンの可能性をチェックする
            ////////////////////// short position is opened//////////////////////////////////////////////
           else {//SELL
               // check profit 
                //               if(Ask < (OrderStopLoss() - (sl_sell1 * YYY + spread) * Poin)) 
                //               if(Ask < (OrderStopLoss() - (sl_buy1 * YYY + spread) * Poin)) 
               if ( (Average_Price_NOW_OP_SELL - averagePriceInTimeFrame11 >= 0) 
                    && ((Ask + sl_sell2 * pipValue) <= OrderStopLoss())) {
                   if ((averageCandlestick(time18, 1) <= averageCandlestick(time18, 2))
                        || (averageCandlestick(time19, 1) <= averageCandlestick(time19, 2))
                        || ((iHigh(NULL,time19,1)+iLow(NULL,time19,1))/2 <= (iHigh(NULL,time19,2)+iLow(NULL,time19,2))/2)
                        || ((iHigh(NULL,time18,1)+iLow(NULL,time18,1))/2 <= (iHigh(NULL,time18,2)+iLow(NULL,time18,2))/2)
                        ) {
                        //bool OrderModify( int ticket, double price, double stoploss, double takeprofit, datetime expiration, color Color=CLR_NONE)
                        if(!OrderModify(OrderTicket(), OrderOpenPrice(), Ask + sl_sell2 * pipValue,Ask - tp_sell1 * pipValue, 0, clrSpringGreen)) 
                        {
                            Sleep(30000);
                            //prevtime = Time[1];
                            lastTimeCheckPoint = iTime(NULL, minTimeFrame, 1);
                        }                        
                   }
               }
             }
            // exit
            //return(0); //why?
         }
     }// End for
     
     

    ///////////////////////////////////////////////////// check for long or short position possibility/////////////////////////////////////////
   if(//Buy cond1
         perceptron1() >= Const_buy_time1
        && perceptron2() >= Const_buy_time2
        && perceptron3() >= Const_buy_time3                       
        && perceptron4() >= Const_buy_time4
        && perceptron5() >= Const_buy_time6                       
        && perceptron6() >= Const_buy_time7
        && perceptron7() >= Const_buy_time8) 
     { //long
        placeLongOrder();
     }
     
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(//Buy cond2
        HO_OL_time25 >=  Const_Buy_time25
      && HO_OL_time26 >=  Const_Buy_time26
      && HO_OL_time31 >=  Const_Buy_time31
      && HO_OL_time32 >=  Const_Buy_time32
      
      && HO_OL_time25 <=  Const_Buy_time25_MAX
      && HO_OL_time26 <=  Const_Buy_time26_MAX
      && HO_OL_time31 <=  Const_Buy_time31_MAX
      && HO_OL_time32 <=  Const_Buy_time32_MAX
      && ( 2*iWPR(NULL,time29,wpr_period_time29,1)+1*iWPR(NULL,time29,wpr_period_time29,2) )/3.0  <= wpr_conts_buy_time29         
     ) 
     { //long
        placeLongOrder();
     } 
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(//Buy cond3
             HO_OL_time25 >=  Const_Buy_time25
          && HO_OL_time26 >=  Const_Buy_time26
          && HO_OL_time31 >=  Const_Buy_time31
          && HO_OL_time32 >=  Const_Buy_time32
          && HO_OL_time33 >=  Const_Buy_time33
          
          && HO_OL_time25 <=  Const_Buy_time25_MAX
          && HO_OL_time26 <=  Const_Buy_time26_MAX
          && HO_OL_time31 <=  Const_Buy_time31_MAX
          && HO_OL_time32 <=  Const_Buy_time32_MAX
          && HO_OL_time33 <=  Const_Buy_time33_MAX
          && ( 2*iWPR(NULL,time30,wpr_period_time30,1)+1*iWPR(NULL,time30,wpr_period_time30,2) )/3.0  <= wpr_conts_buy_time30         
     ) 
     { //long
        placeLongOrder();
     } 
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(//Buy cond4
         HO_OL_time26 >=  Const_Buy_time26
      && HO_OL_time27 >=  Const_Buy_time27
      && HO_OL_time31 >=  Const_Buy_time31
      && HO_OL_time32 >=  Const_Buy_time32
      && HO_OL_time33 >=  Const_Buy_time33
      
      && HO_OL_time26 <=  Const_Buy_time26_MAX
      && HO_OL_time27 <=  Const_Buy_time27_MAX
      && HO_OL_time31 <=  Const_Buy_time31_MAX
      && HO_OL_time32 <=  Const_Buy_time32_MAX
      && HO_OL_time33 <=  Const_Buy_time33_MAX
      && ( 2*iWPR(NULL,time29,wpr_period_time29,1)+1*iWPR(NULL,time29,wpr_period_time29,2) )/3.0  <= wpr_conts_buy_time29         
     ) 
     { //long
        placeLongOrder();
     } 
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(//Buy cond5
             HO_OL_time26 >=  Const_Buy_time26
          && HO_OL_time27 >=  Const_Buy_time27
          && HO_OL_time31 >=  Const_Buy_time31
          && HO_OL_time32 >=  Const_Buy_time32
          && HO_OL_time34 >=  Const_Buy_time34
          
          && HO_OL_time26 <=  Const_Buy_time26_MAX
          && HO_OL_time27 <=  Const_Buy_time27_MAX
          && HO_OL_time31 <=  Const_Buy_time31_MAX
          && HO_OL_time32 <=  Const_Buy_time32_MAX
          && HO_OL_time34 <=  Const_Buy_time34_MAX
          && ( 2*iWPR(NULL,time30,wpr_period_time30,1)+1*iWPR(NULL,time30,wpr_period_time30,2) )/3.0  <= wpr_conts_buy_time30         
     ) 
     { //long
        placeLongOrder();
     } 
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  

    if(//Buy cond6
             HO_OL_time27 >=  Const_Buy_time27
          && HO_OL_time28 >=  Const_Buy_time28
          && HO_OL_time31 >=  Const_Buy_time31
          && HO_OL_time32 >=  Const_Buy_time32
          && HO_OL_time34 >=  Const_Buy_time34
          
          && HO_OL_time27 <=  Const_Buy_time27_MAX
          && HO_OL_time28 <=  Const_Buy_time28_MAX
          && HO_OL_time31 <=  Const_Buy_time31_MAX
          && HO_OL_time32 <=  Const_Buy_time32_MAX
          && HO_OL_time34 <=  Const_Buy_time34_MAX
          && ( 2*iWPR(NULL,time29,wpr_period_time29,1)+1*iWPR(NULL,time29,wpr_period_time29,2) )/3.0  <= wpr_conts_buy_time29         
     ) 
     { //long
        placeLongOrder();
     } 
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(//Buy cond7
             HO_OL_time27 >=  Const_Buy_time27
          && HO_OL_time28 >=  Const_Buy_time28
          && HO_OL_time31 >=  Const_Buy_time31
          && HO_OL_time32 >=  Const_Buy_time32
          && HO_OL_time34 >=  Const_Buy_time34
          
          && HO_OL_time27 <=  Const_Buy_time27_MAX
          && HO_OL_time28 <=  Const_Buy_time28_MAX
          && HO_OL_time31 <=  Const_Buy_time31_MAX
          && HO_OL_time32 <=  Const_Buy_time32_MAX
          && HO_OL_time34 <=  Const_Buy_time34_MAX
          && ( 2*iWPR(NULL,time30,wpr_period_time30,1)+1*iWPR(NULL,time30,wpr_period_time30,2) )/3.0  <= wpr_conts_buy_time30         
     ) 
     { //long
        placeLongOrder();
     }
///////////////////////////////////////////////////// check for long or short position possibility///////////////////////////////////////// 
    //else if( //Sell cond1
    if(      perceptron1()  <=Const_sell_time1*(-1.000)
          && perceptron2()  <=Const_sell_time2*(-1.000)
          && perceptron3()  <=Const_sell_time3*(-1.000)
          && perceptron4()  <=Const_sell_time4*(-1.000)  
          && perceptron5()  <=Const_sell_time6*(-1.000)
          && perceptron6()  <=Const_sell_time7*(-1.000)   
          && perceptron7()  <=Const_sell_time8*(-1.000)                    
          )
     { // short
        placeShortOrder();
     }
    
    if( //Sell cond2
         OL_HO_time25 >=  Const_Sell_time25
      && OL_HO_time26 >=  Const_Sell_time26
      && OL_HO_time31 >=  Const_Sell_time31
      && OL_HO_time32 >=  Const_Sell_time32
      && OL_HO_time25 <=  Const_Sell_time25_MAX
      && OL_HO_time26 <=  Const_Sell_time26_MAX
      && OL_HO_time31 <=  Const_Sell_time31_MAX
      && OL_HO_time32 <=  Const_Sell_time32_MAX
      && ( 2*iWPR(NULL,time29,wpr_period_time29,1)+1*iWPR(NULL,time29,wpr_period_time29,2) )/3.0  >= wpr_conts_sell_time29                     
          )
     { // short
        placeShortOrder();
     }
     
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
    if( //Sell cond3
             OL_HO_time25 >=  Const_Sell_time25
          && OL_HO_time26 >=  Const_Sell_time26
          && OL_HO_time31 >=  Const_Sell_time31
          && OL_HO_time32 >=  Const_Sell_time32
          && OL_HO_time33 >=  Const_Sell_time33
          && OL_HO_time25 <=  Const_Sell_time25_MAX
          && OL_HO_time26 <=  Const_Sell_time26_MAX
          && OL_HO_time31 <=  Const_Sell_time31_MAX
          && OL_HO_time32 <=  Const_Sell_time32_MAX
          && OL_HO_time33 <=  Const_Sell_time33_MAX
          && ( 2*iWPR(NULL,time30,wpr_period_time30,1)+1*iWPR(NULL,time30,wpr_period_time30,2) )/3.0  >= wpr_conts_sell_time30                     
          )
     { // short
        placeShortOrder();
     }
     
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
     if( //Sell cond4
             OL_HO_time27 >=  Const_Sell_time27
          && OL_HO_time26 >=  Const_Sell_time26
          && OL_HO_time31 >=  Const_Sell_time31
          && OL_HO_time32 >=  Const_Sell_time32
          && OL_HO_time34 >=  Const_Sell_time34

          && OL_HO_time27 <=  Const_Sell_time27_MAX
          && OL_HO_time26 <=  Const_Sell_time26_MAX
          && OL_HO_time31 <=  Const_Sell_time31_MAX
          && OL_HO_time32 <=  Const_Sell_time32_MAX
          && OL_HO_time34 <=  Const_Sell_time34_MAX
          && ( 2*iWPR(NULL,time29,wpr_period_time29,1)+1*iWPR(NULL,time29,wpr_period_time29,2) )/3.0  >= wpr_conts_sell_time29                     
          )
     { // short
        placeShortOrder();
     }
     
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
    if( //Sell cond5
             OL_HO_time27 >=  Const_Sell_time27
          && OL_HO_time26 >=  Const_Sell_time26
          && OL_HO_time31 >=  Const_Sell_time31
          && OL_HO_time32 >=  Const_Sell_time32
          && OL_HO_time34 >=  Const_Sell_time34

          && OL_HO_time27 <=  Const_Sell_time27_MAX
          && OL_HO_time26 <=  Const_Sell_time26_MAX
          && OL_HO_time31 <=  Const_Sell_time31_MAX
          && OL_HO_time32 <=  Const_Sell_time32_MAX
          && OL_HO_time34 <=  Const_Sell_time34_MAX
          && ( 2*iWPR(NULL,time30,wpr_period_time30,1)+1*iWPR(NULL,time30,wpr_period_time30,2) )/3.0  >= wpr_conts_sell_time30                     
          )
     { // short
        placeShortOrder();
     }
 
 
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    if( //Sell cond6
             OL_HO_time27 >=  Const_Sell_time27
          && OL_HO_time28 >=  Const_Sell_time28
          && OL_HO_time31 >=  Const_Sell_time31
          && OL_HO_time32 >=  Const_Sell_time32
          && OL_HO_time34 >=  Const_Sell_time34
          
          && OL_HO_time27 <=  Const_Sell_time27_MAX
          && OL_HO_time28 <=  Const_Sell_time28_MAX
          && OL_HO_time31 <=  Const_Sell_time31_MAX
          && OL_HO_time32 <=  Const_Sell_time32_MAX
          && OL_HO_time34 <=  Const_Sell_time34_MAX
          && ( 2*iWPR(NULL,time29,wpr_period_time29,1)+1*iWPR(NULL,time29,wpr_period_time29,2) )/3.0  >= wpr_conts_sell_time29                     
          )
     { // short
        placeShortOrder();
     }
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
    
    if( //Sell cond7
             OL_HO_time27 >=  Const_Sell_time27
          && OL_HO_time28 >=  Const_Sell_time28
          && OL_HO_time31 >=  Const_Sell_time31
          && OL_HO_time32 >=  Const_Sell_time32
          && OL_HO_time34 >=  Const_Sell_time34

          && OL_HO_time27 <=  Const_Sell_time27_MAX
          && OL_HO_time28 <=  Const_Sell_time28_MAX
          && OL_HO_time31 <=  Const_Sell_time31_MAX
          && OL_HO_time32 <=  Const_Sell_time32_MAX
          && OL_HO_time34 <=  Const_Sell_time34_MAX
          && ( 2*iWPR(NULL,time30,wpr_period_time30,1)+1*iWPR(NULL,time30,wpr_period_time30,2) )/3.0  >= wpr_conts_sell_time30                     
          )
     { // short
        placeShortOrder();
     }
};


void placeLongOrder() {
    if (TimeCurrent()- lastBuyTime < waite_BUY6*60) return;
    countBuySellPosition();
    if (gCountBuy >= BuyEntryMaxNumber) {
        PrintFormat("Number of buy positions exceeds limitation %d", BuyEntryMaxNumber);
        return;
    }
    
    double SL = 0, ecnSL = 0, TP = 0;
    if (!ECN_Mode) {
        SL = Ask - sl_buy3 * pipValue;
    } else {
        ecnSL = Ask - sl_buy3 * pipValue;
        SL = Ask - StopLossDefaultBuy*pipValue;
    }    
    
    TP = Ask + TakeProfitDefaultBuy*pipValue;
    
    //int ticket = OrderSend(Symbol(), OP_BUY, lots, Ask, 3, SL, 0, "", MagicNumber, 0, clrSalmon);
    int ticket = OrderSend(Symbol(), OP_BUY, LOT_SIZE, Ask, 3, SL, TP, "", MAGIC_NUMBER, 0, clrSalmon);
    //----
    if(ticket < 0) 
    {
        Sleep(30000);
        //prevtime = Time[1];
        lastTimeCheckPoint = iTime(NULL, minTimeFrame, 1);
    }
    else if ((ticket > 0) && (ECN_Mode))
    {
        OrderSelect(ticket,SELECT_BY_TICKET);
        OrderModify(OrderTicket(), OrderOpenPrice(), ecnSL, OrderTakeProfit(), 0);
    }
    
    if (ticket > 0) {
      lastBuyTime = TimeCurrent();
      lastOpenTime = lastBuyTime;
    }
}

void placeShortOrder() {

    if (TimeCurrent()- lastSellTime < waite_SELL6*60) return;
    
    countBuySellPosition();
    if (gCountSell >= SellEntryMaxNumber) {
        PrintFormat("Number of sell positions exceeds limitation %d", SellEntryMaxNumber);
        return;
    }
        
    double SL = 0, ecnSL = 0, TP = 0;
    //if (!ECN_Mode) SL = Ask + sl_sell3 * pipValue;
    //else ecnSL = Ask + sl_sell3 * pipValue;
    //int ticket = OrderSend(Symbol(), OP_SELL, lots, Bid, 3, SL, 0, "",  MagicNumber, 0, clrOrangeRed); 
    if (!ECN_Mode) {
        SL = Bid + sl_sell3 * pipValue;
    } else {
        ecnSL = Bid + sl_sell3 * pipValue;
        SL = Bid + StopLossDefaultSell*pipValue;
    };
    //SL = Bid + StopLossDefaultSell*pipValue;
    TP = Bid - TakeProfitDefaultSell*pipValue;    
    
    //int ticket = OrderSend(Symbol(), OP_SELL, lots, Bid, 3, SL, 0, "",  MagicNumber, 0, clrOrangeRed); 
    int ticket = OrderSend(Symbol(), OP_SELL, LOT_SIZE, Bid, 3, SL, TP, "",  MAGIC_NUMBER, 0, clrOrangeRed); 

    if(ticket < 0) {       
        Sleep(30000);
       //prevtime = Time[1];
       lastTimeCheckPoint = iTime(NULL, minTimeFrame, 1);
    } else if ((ticket > 0) && (ECN_Mode))
        {
         OrderSelect(ticket,SELECT_BY_TICKET);
         OrderModify(OrderTicket(), OrderOpenPrice(), ecnSL, OrderTakeProfit(), 0);
    }

    if (ticket > 0) {
      lastSellTime = TimeCurrent();
      lastOpenTime = lastSellTime;
    }
}

//perceptron(
double perceptron(int timeframe, int period, int ma_method, int applied_price, int AOI, int itemCount) {
    double a1 = iForce(NULL, timeframe, period, ma_method, applied_price, 1);
    double sum = 0;
    for (int ind = 1; ind <= itemCount; ind ++) {
        sum = sum + MathAbs(iForce(NULL, timeframe, period, ma_method, applied_price, ind));
        /*
        sum = sum + MathAbs(iForce(NULL, timeframe, period, ma_method, applied_price
                            , 1 + (int)MathMod(MathRand(), MathRound(AOI*Golden_Ratio)*ind)));
         */
    }
        
    //2 + (int)MathMod(MathRand(), itemCount)
    double bairitu = sum/itemCount;
    //MathSrand(GetTickCount())
    if (bairitu == 0) return 0;
    return a1/bairitu;
}  


//--------------------------------------------------------------------

//注文が残ってたら決済
int MyClose( int ordType )
{
    int            result = 0, num, i, ticket = -1;    
    int orderCount = OrdersTotal();
    int closeOrderList[1]; 
    ArrayResize(closeOrderList, orderCount);
    int closeCount = 0;
    
    ////PrintFormat("orderCount = %d", orderCount);
    //注文の数だけループ
    for( i = 0; i < orderCount; i++ )
    //for( i = orderCount - 1; i >=0 ; i-- )
    {
        //決済が終わってないのなら、選択
        if( OrderSelect(i, SELECT_BY_POS, MODE_TRADES) == true )
        {
           ////PrintFormat("checking #%d/%d", OrderTicket());
            //通貨とマジックナンバーが一致していたら
            if( OrderSymbol() == Symbol() && ( MAGIC_NUMBER == 0 || OrderMagicNumber() == MAGIC_NUMBER ))
            {
                //注文タイプが一致していたら
                if( OrderType() == ordType )
                {
                   closeOrderList[closeCount] = OrderTicket();
                   closeCount = closeCount + 1;
               /*
                    num = MyCloseSend( ordType );
                    if( num == 0 && 0 <= result ) result++;
                    else result = -1;
                   */
                }
            }
        }
    };
    
    for( i = 0; i < closeCount; i++ ) {
       if (closeOrder(closeOrderList[i])) result++;
    }
    return ( result );
}

bool closeOrder(int orderNo) {
    int repeat = 10;
    bool    result;    
    for( int i = 0; i < repeat; i++)
    {
        //注文用のスレッドが空いてるのなら
        if( IsTradeAllowed() )
        {    
          if (OrderSelect(orderNo, SELECT_BY_TICKET, MODE_TRADES)) {
              if ( OrderType() == OP_BUY ) result = OrderClose( orderNo, OrderLots(), Bid, spread );  //bool OrderClose(int ticket, double lots, double price, int slippage, int color color=CLR_NONE)
              else if ( OrderType() == OP_SELL ) result = OrderClose( orderNo, OrderLots(), Ask, spread );  //bool OrderClose(int ticket, double lots, double price, int slippage, int color color=CLR_NONE)
              else result = OrderDelete( orderNo );
              //結果がエラーなら表示、成功なら抜ける
              if ( result == False ) Print( "OrderSend error = ", GetLastError());
              else return (True);    
          };
      };
        //1秒待機
        Sleep(1000);       
   };
    return False;
}


//注文処理 Order processing
int MyCloseSend( int ordType )
{
    int        ticket = -1, repeat = 10;
    bool    result;
    
    //このチケットNoと情報を取得 Get this ticket's and information
    ticket = OrderTicket();
    
    //指定の回数だけループ A specified number of times loop
    for( int i = 0; i < repeat; i++)
    {
        //注文用のスレッドが空いてるのなら
        if( IsTradeAllowed() )
        {
            //注文を送信
            if ( OrderType() == OP_BUY ) result = OrderClose( ticket, OrderLots(), Bid, spread );  //bool OrderClose(int ticket, double lots, double price, int slippage, int color color=CLR_NONE)
            else if ( OrderType() == OP_SELL ) result = OrderClose( ticket, OrderLots(), Ask, spread );  //bool OrderClose(int ticket, double lots, double price, int slippage, int color color=CLR_NONE)
            else result = OrderDelete( ticket );
            
            //結果がエラーなら表示、成功なら抜ける
            if ( result == False ) Print( "OrderSend error = ", GetLastError());
            else return ( 0 );
        }        
        //1秒待機
        Sleep(1000); 
    }
    
    return ( -1 );
}

//--------------------------------------------------------------------

double averageCandlestick(int timeFrame, int pos) {
    return (iHigh(NULL,timeFrame, pos) + iLow(NULL,timeFrame, pos) + iClose(NULL,timeFrame, pos) + iOpen(NULL,timeFrame, pos) )/4;
}

void checkEndCloseTrades(double Average_Price_NOW_OP_BUY, double Average_Price_NOW_OP_SELL) {
    // Conditions on perceptron
    /*    
    if( 
        perceptron1()  <=Const_sell_time1*(-1.000)
        && perceptron2()  <=Const_sell_time2*(-1.000)
        && perceptron3()  <=Const_sell_time3*(-1.000)
        && perceptron4()  <=Const_sell_time4*(-1.000) 
        && perceptron5()  <=Const_sell_time6*(-1.000)  
        && perceptron6()  <=Const_sell_time7*(-1.000)  
        && perceptron7()  <=Const_sell_time8*(-1.000)                     
       )
    {
        //すべて決済
        MyClose( OP_BUY );
    }
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    if(
        perceptron1() >=Const_buy_time1
        && perceptron2() >=Const_buy_time2
        && perceptron3() >=Const_buy_time3
        && perceptron4() >=Const_buy_time4   
        && perceptron5() >=Const_buy_time6    
        && perceptron6() >=Const_buy_time7
        && perceptron7() >=Const_buy_time8                                         
       )
    {
        //すべて決済
        MyClose( OP_SELL );
    }
    */
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////

    double averageInTime11 = averageCandlestick(time11, 1);
    int lifeTime = TimeCurrent()- OrderOpenTime();
    
    if (averageInTime11 >= Average_Price_NOW_OP_BUY) {
        if ((lifeTime >= (waite_BUY1) * 60) ||
            (lifeTime > (MathRound(waite_BUY1*root2)) * 60) || 
            (lifeTime > (MathRound(waite_BUY1*Golden_Ratio)) * 60) ||
            (lifeTime > (MathRound(waite_BUY1*root2*root2)) * 60) ||
            (lifeTime > (MathRound(waite_BUY1*Golden_Ratio*Golden_Ratio)) * 60) ||
            (lifeTime > (MathRound(waite_BUY1*root2*2)) * 60) ||
            (lifeTime > (MathRound(waite_BUY1*Golden_Ratio*2)) * 60) ||
            (lifeTime > (MathRound(waite_BUY1*root2*root2*2)) * 60) ||
            (lifeTime > (MathRound(waite_BUY1*Golden_Ratio*Golden_Ratio*2)) * 60) ||
            (lifeTime > (MathRound(waite_BUY1*Golden_Ratio*root2)) * 60)
            ) {
                MyClose( OP_BUY );
        };
    };
    
    if (Average_Price_NOW_OP_SELL >=  averageInTime11) {
        if ((lifeTime >= (waite_SELL1) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*root2)) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*Golden_Ratio)) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*root2*root2)) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*Golden_Ratio*Golden_Ratio)) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*root2*2)) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*Golden_Ratio*2)) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*root2*root2*2)) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*Golden_Ratio*Golden_Ratio*2)) * 60) ||
            (lifeTime > (MathRound(waite_SELL1*Golden_Ratio*root2)) * 60)
            ) {
                MyClose( OP_SELL );
        };
    };
    
    
    // Conditions on iBands 
    if ((lifeTime > (waite_BUY3) * 60) || (lifeTime >= (waite_BUY4) * 60) || (lifeTime > (waite_BUY5) * 60)){
        if ((averageInTime11 >= iBands(NULL,time12,band_period_time12,siguma_time12,0,PRICE_WEIGHTED,MODE_UPPER,1)) ||
             (averageInTime11 >= iBands(NULL,time13,band_period_time13,siguma_time13,0,PRICE_WEIGHTED,MODE_UPPER,1)) ||
             (averageInTime11 >= iBands(NULL,time14,band_period_time14,siguma_time14,0,PRICE_WEIGHTED,MODE_UPPER,1)) ||
             (averageInTime11 >= iBands(NULL,time15,band_period_time15,siguma_time15,0,PRICE_WEIGHTED,MODE_UPPER,1)) ||
             (averageInTime11 >= iBands(NULL,time16,band_period_time16,siguma_time16,0,PRICE_WEIGHTED,MODE_UPPER,1)) ||
             (averageInTime11 >= iBands(NULL,time17,band_period_time17,siguma_time17,0,PRICE_WEIGHTED,MODE_UPPER,1)) ||
             (averageInTime11 >= iBands(NULL,time20,band_period_time20,siguma_time20,0,PRICE_WEIGHTED,MODE_UPPER,1)) ||
             (averageInTime11 >= iBands(NULL,time21,band_period_time21,siguma_time21,0,PRICE_WEIGHTED,MODE_UPPER,1)) ||
             (averageInTime11 >= iBands(NULL,time22,band_period_time22,siguma_time22,0,PRICE_WEIGHTED,MODE_UPPER,1)) 
            ){
            MyClose( OP_BUY );
        };   
    };

    if ((lifeTime > (waite_SELL3) * 60) || (lifeTime >= (waite_SELL4) * 60) || (lifeTime > (waite_SELL5) * 60)){
        if ((averageInTime11 <=  iBands(NULL,time12,band_period_time12,siguma_time12,0,PRICE_WEIGHTED,MODE_LOWER,1)) ||
            (averageInTime11 <= iBands(NULL,time13,band_period_time13,siguma_time13,0,PRICE_WEIGHTED,MODE_LOWER,1)) ||
            (averageInTime11 <= iBands(NULL,time14,band_period_time14,siguma_time14,0,PRICE_WEIGHTED,MODE_LOWER,1)) ||
            (averageInTime11 <= iBands(NULL,time15,band_period_time15,siguma_time15,0,PRICE_WEIGHTED,MODE_LOWER,1)) ||
            (averageInTime11 <= iBands(NULL,time16,band_period_time16,siguma_time16,0,PRICE_WEIGHTED,MODE_LOWER,1)) ||
            (averageInTime11 <= iBands(NULL,time17,band_period_time17,siguma_time17,0,PRICE_WEIGHTED,MODE_LOWER,1)) ||
            (averageInTime11 <= iBands(NULL,time20,band_period_time20,siguma_time20,0,PRICE_WEIGHTED,MODE_LOWER,1)) ||
            (averageInTime11 <= iBands(NULL,time21,band_period_time21,siguma_time21,0,PRICE_WEIGHTED,MODE_LOWER,1)) ||
            (averageInTime11 <= iBands(NULL,time22,band_period_time22,siguma_time22,0,PRICE_WEIGHTED,MODE_LOWER,1))
            ){
            MyClose( OP_SELL );
        };
    };
}

//+------------------------------------------------------------------+
//| The PERCEPTRON - a perceiving and recognizing function           |
//+------------------------------------------------------------------+
double perceptron1(){
  return perceptron(time1, force_period_time1, MODE_LWMA, PRICE_WEIGHTED, AOI1,  itemCount_time1);
}
  
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//| The PERCEPTRON - a perceiving and recognizing function           |
//+------------------------------------------------------------------+
double perceptron2(){
   return perceptron(time2, force_period_time2, MODE_LWMA, PRICE_WEIGHTED, AOI2,  itemCount_time2);
}

//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//| The PERCEPTRON - a perceiving and recognizing function           |
//+------------------------------------------------------------------+
double perceptron3(){
    return perceptron(time3, force_period_time3, MODE_LWMA, PRICE_WEIGHTED, AOI3,  itemCount_time3);
}

//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//| The PERCEPTRON - a perceiving and recognizing function           |
//+------------------------------------------------------------------+
double perceptron4(){
    return perceptron(time4, force_period_time4, MODE_LWMA, PRICE_WEIGHTED, AOI4,  itemCount_time4);
}

//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//| The PERCEPTRON - a perceiving and recognizing function           |
//+------------------------------------------------------------------+
double perceptron5(){
    return perceptron(time6, force_period_time6, MODE_LWMA, PRICE_WEIGHTED, AOI6,  itemCount_time6);
}

//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//| The PERCEPTRON - a perceiving and recognizing function           |
//+------------------------------------------------------------------+
double perceptron6(){
    return perceptron(time7, force_period_time7, MODE_LWMA, PRICE_WEIGHTED, AOI7,  itemCount_time7);
}

//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//+------------------------------------------------------------------+
//| The PERCEPTRON - a perceiving and recognizing function           |
//+------------------------------------------------------------------+
double perceptron7(){
    return perceptron(time8, force_period_time8, MODE_LWMA, PRICE_WEIGHTED, AOI8,  itemCount_time8);
}

//+------------------------------------------------------------------+
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void findMinTimeFrame() {
    // Determine minimum timeframe
    minTimeFrame = time1;
    
    if (minTimeFrame > time2) {
        minTimeFrame = time2;
    }

    if (minTimeFrame > time3) {
        minTimeFrame = time3;
    }

    if (minTimeFrame > time4) {
        minTimeFrame = time4;
    }

    if (minTimeFrame > time5) {
        minTimeFrame = time5;
    }

    if (minTimeFrame > time6) {
        minTimeFrame = time6;
    }

    if (minTimeFrame > time7) {
        minTimeFrame = time7;
    }
    
    if (minTimeFrame > time8) {
        minTimeFrame = time8;
    }

    if (minTimeFrame > time11) {
        minTimeFrame = time11;
    }

    if (minTimeFrame > time12) {
        minTimeFrame = time12;
    }
    
    if (minTimeFrame > time13) {
        minTimeFrame = time13;
    }
    
    if (minTimeFrame > time14) {
        minTimeFrame = time14;
    }
    
    if (minTimeFrame > time15) {
        minTimeFrame = time15;
    }
    
    if (minTimeFrame > time16) {
        minTimeFrame = time16;
    }
    
    if (minTimeFrame > time17) {
        minTimeFrame = time17;
    }
    
    if (minTimeFrame > time18) {
        minTimeFrame = time18;
    }
    
    if (minTimeFrame > time19) {
        minTimeFrame = time19;
    }        
    
    if (minTimeFrame > time20) {
        minTimeFrame = time20;
    } 
    
    if (minTimeFrame > time21) {
        minTimeFrame = time21;
    } 
    
    if (minTimeFrame > time22) {
        minTimeFrame = time22;
    } 
    /*
    if (minTimeFrame > time23) {
        minTimeFrame = time23;
    } 
    
    if (minTimeFrame > time24) {
        minTimeFrame = time24;
    }
    */
    if (minTimeFrame > time25) {
        minTimeFrame = time25;
    }
    
    if (minTimeFrame > time26) {
        minTimeFrame = time26;
    }
    
    if (minTimeFrame > time27) {
        minTimeFrame = time27;
    }    
    
    if (minTimeFrame > time28) {
        minTimeFrame = time28;
    }  
    
    if (minTimeFrame > time29) {
        minTimeFrame = time29;
    }  
    
    if (minTimeFrame > time30) {
        minTimeFrame = time30;
    }  
    
    if (minTimeFrame > time31) {
        minTimeFrame = time31;
    }  
    
    if (minTimeFrame > time32) {
        minTimeFrame = time32;
    }  
    
    if (minTimeFrame > time33) {
        minTimeFrame = time33;
    }
    
    if (minTimeFrame > time34) {
        minTimeFrame = time34;
    }    
}

 void displayDelayMessageBackGround() {
   string strBackGrd1 = StringConcatenate(STR_OBJ_PREFIX, "_BackGroundA01");
   string strBackGrd2 = StringConcatenate(STR_OBJ_PREFIX, "_BackGroundA02");      
   string strBackGrd3 = StringConcatenate(STR_OBJ_PREFIX, "_BackGroundA03");
   string strBackGrd4 = StringConcatenate(STR_OBJ_PREFIX, "_BackGroundA04");
   string strBackGrd5 = StringConcatenate(STR_OBJ_PREFIX, "_BackGroundA05");
   string strBackGrd6 = StringConcatenate(STR_OBJ_PREFIX, "_BackGroundA06");
   string strBackGrd7 = StringConcatenate(STR_OBJ_PREFIX, "_BackGroundA07");
   //string strBackGrd8 = StringConcatenate(STR_OBJ_PREFIX, "_BackGroundA08");
   string strTxtIndicatorName = StringConcatenate(STR_OBJ_PREFIX, "_h2Tite");
   
   TextLabel(strBackGrd1, 5, 16, CORNER_LEFT_UPPER,  "g", 35, "Webdings", clrDarkGray);
   TextLabel(strBackGrd2, 45, 16, CORNER_LEFT_UPPER,  "g", 35, "Webdings", clrDarkGray);         
   TextLabel(strBackGrd3, 85, 16, CORNER_LEFT_UPPER,  "g", 35, "Webdings", clrDarkGray);
   TextLabel(strBackGrd4, 125, 16, CORNER_LEFT_UPPER,  "g", 35, "Webdings", clrDarkGray);
   TextLabel(strBackGrd5, 165, 16, CORNER_LEFT_UPPER,  "g", 35, "Webdings", clrDarkGray);
   TextLabel(strBackGrd6, 205, 16, CORNER_LEFT_UPPER,  "g", 35, "Webdings", clrDarkGray);
   TextLabel(strBackGrd7, 245, 16, CORNER_LEFT_UPPER,  "g", 35, "Webdings", clrDarkGray);
   //TextLabel(strBackGrd8, 285, 16, CORNER_LEFT_UPPER,  "g", 35, "Webdings", clrDarkGray);
   //TextLabel( strBackGrd6, 290, 16, CORNER_LEFT_UPPER,  "g", 55, "Webdings", clrDarkGray);
            
   //TextLabel(strTxtIndicatorName, 12, 22, CORNER_LEFT_UPPER, INDICATOR_LABEL, 11, "Arial Bold", Yellow);   
}


void TextLabel(string lblname, int xOffset, int yOffset,int iCorner, string Text, int FontSize, string FontName, color txtcolor)  
{      
   if (ObjectFind( lblname)>0) ObjectDelete(lblname);
   ObjectCreate(lblname,OBJ_LABEL         , 0, 0, 0 );
   ObjectSet   (lblname,OBJPROP_CORNER    , iCorner);
   ObjectSet   (lblname,OBJPROP_XDISTANCE , xOffset); 
   ObjectSet   (lblname,OBJPROP_YDISTANCE , yOffset);
   ObjectSet   (lblname,OBJPROP_BACK      , false );
   ObjectSetText( lblname, Text, FontSize, FontName, txtcolor );   
}

void deleteCommentText() {
  ObjectsDeleteAll(0, STR_OBJ_PREFIX, 0, OBJ_LABEL);
}
'''
